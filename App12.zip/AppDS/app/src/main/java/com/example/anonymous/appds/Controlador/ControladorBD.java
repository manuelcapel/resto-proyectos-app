package com.example.anonymous.appds.Controlador;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.anonymous.appds.Modelo.TablaPreguntas;
import com.example.anonymous.appds.Modelo.TablaRecords;


/**
 * Clase ControladorBD que gestiona la Base de Datos de la aplicacion
 */
public class ControladorBD {
    final static int VERSION = 1;
    final static String DB_NAME = "Juego";

    private DBOpenHelper dbHelper;
    private SQLiteDatabase sqlDB;

    TablaPreguntas Preguntas;
    TablaRecords Records;
    Context ctx=null;

    /**
     * Constructor.
     *
     * @param context
     */
    public ControladorBD(Context context) {
        ctx=context;
        dbHelper = new DBOpenHelper(ctx);

    }

    /**
     * Abre la conexión con la base de datos.
     */
    public void open() {
        sqlDB = dbHelper.getWritableDatabase();

        Preguntas = new TablaPreguntas(sqlDB);
        if(Preguntas.isEmpty())
            Rellenar(ctx);
        Records = new TablaRecords(sqlDB);
    }

    /**
     * Cierra la conexión con la base de datos.
     */
    public void close() {
        sqlDB.close();
    }

    /**
     * Comprueba si la TablaRecords está vacía.
     *
     * @return true si está vacía.
     */
    public boolean RecordsIsEmpty() {
        return TablaRecords.isEmpty();
    }
    /**
     * Comprueba si la TablaPreguntas está vacía.
     *
     * @return true si está vacía.
     */
    public boolean PreguntasIsEmpty() {
        return TablaPreguntas.isEmpty();
    }

    /**
     * Devuelve el cursor con todos las tuplas de la Tabla
     *
     * @return Cursor
     */
    public Cursor getRecords() {
        return TablaRecords.getTabla();
    }

    /**
     * Devuelve el cursor con todos las tuplas de la Tabla
     *
     * @return Cursor
     */
    public Cursor getPreguntas() {
        return TablaPreguntas.getTabla();
    }


    /**
     * Rellena la tabla preguntas con las preguntas que debera de tener
     *
     */
    public void Rellenar(Context context) {
        TablaPreguntas.rellenar(context);
    }

    /**
     * Devuelve el cursor con los valores seleccionador de todas las tuplas de la Tabla
     *
     * @param x
     * @param y
     * @param z
     * @param w
     *
     * @return Cursor
     */
    public Cursor getRecords(String x,String y, String z, String w) {
        return TablaRecords.getTabla4(x, y,z,w);
    }

    /**
     * Inserta una tupla en la TablaRecords si se ha batido algún record.
     *
     * @param nombre
     * @param tematica
     * @param puntos
     * @param tiempo
     *
     * @return true si se inserta correctamente.
     */
    public boolean RecordsInsert(String nombre, String tematica, int puntos, int fallos,int tiempo) {
        if(!TablaRecords.isEmpty()){
            int pos=-1;
            int puntillos=0;
            int tiempillo=0;
            Cursor c = TablaRecords.getTabla();
            boolean continua=true;
            for(int i=0;i<TablaRecords.get_num()&& continua;++i){
                c.moveToPosition(i);
                puntillos=Integer.parseInt(c.getString(3));
                tiempillo=Integer.parseInt(c.getString(4));
                if(puntillos<puntos){
                    pos=i;
                    continua=false;
                }
                else {
                    if (puntillos == puntos && tiempillo>tiempo) {
                        pos=i;
                        continua=false;
                    }
                }
            }
            if(TablaRecords.get_num()<10) {
                TablaRecords.insert(nombre, tematica, puntos,fallos, tiempo, TablaRecords.get_num());
                c = TablaRecords.getTabla();
            }

            if(!continua){
                for(int j=(TablaRecords.get_num()-1);j>=pos;--j){//notar que era el maximo 10 records  que mostramos y los desplazamos para abajo
                    c.moveToPosition(j);
                    TablaRecords.actualizar(c.getString(2),c.getString(1),Integer.parseInt(c.getString(3)),
                            Integer.parseInt(c.getString(4)),Integer.parseInt(c.getString(5)),j+1);//String nombre, String tematica, int puntos, int fallos, int tiempo,int pos
                }
                c.moveToPosition(pos);//añadimos el nuevo records
                TablaRecords.actualizar(nombre,tematica,puntos,fallos,tiempo,pos);
                return true;
            }
            else
                return false;
        }
        else{
            return TablaRecords.insert(nombre, tematica, puntos,fallos,tiempo,0);
        }
    }

    /**
     * Clase interna que crea la base de datos y permite la conexión con la BD.
     *
     * @author anonymous
     *
     */
    private class DBOpenHelper extends SQLiteOpenHelper {

        public DBOpenHelper(Context context) {
            super(context, DB_NAME, null, VERSION);
        }

        @Override
        public void onCreate(SQLiteDatabase db) {
            db.execSQL(TablaPreguntas.CREATE_TABLE);
            db.execSQL(TablaRecords.CREATE_TABLE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }

    }
}
