package com.example.anonymous.appds.Controlador;

import android.database.Cursor;

import com.example.anonymous.appds.Modelo.Dato;
import com.example.anonymous.appds.Modelo.Partida;

import java.io.Serializable;

/**
 * Clase ControladorPartida
 */
public class ControladorPartida implements Serializable {

    private Partida partida;

    public ControladorPartida(){
        partida=new Partida();
    }

    public void añadir_acierto(){
        partida.acertada();
    }

    public int get_aciertos(){
        return partida.get_acertadas();
    }
    public int get_total(){
        return partida.get_total();
    }
    public int get_fallos(){
        return (partida.get_total()-partida.get_acertadas());
    }

    public int get_tiempo(){
        return partida.get_time();
    }

    public void set_tiempo(){
        partida.set_time();
    }
    public long get_tiempo_ult(){
        return partida.get_time_ult();
    }
    public void set_tiempo_ult(long x){
        partida.set_time_ult(x);
    }

   /* public int seleccionar_pregunta(Cursor c){
        return partida.nueva_pregunta(c);
    }*/
    public void cargarPreguntas(Cursor c,int num){
        partida.cargarPreguntas(c,num);
    }
    public void mantenerPregunta(){
        partida.set_minusactual();
    }
    public Dato get_pregunta(){
        return partida.get_pregunta();
    }
    public int pregunta_salvada(){
        return partida.ultima();
    }
    public String get_usuario(){
        return partida.get_name();
    }
    public void introducir_usuario(String u){
        partida.set_name(u);
    }
}
