package com.example.anonymous.appds;

/**
 * Clase FabricaPreguntaAudio que implementa la interfaz ServicioPreguntas
 */
public class FabricaPreguntaAudio implements ServicioPreguntas  {

        public Pregunta crearpregunta(){
            return new PreguntaAudio();
        }
}
