package com.example.anonymous.appds;

/**
 * Clase FabricaPreguntaImagen que implementa la interfaz ServicioPreguntas
 */
public class FabricaPreguntaImagen implements ServicioPreguntas  {

    public Pregunta crearpregunta(){
        return new PreguntaImagen();
    }
}
