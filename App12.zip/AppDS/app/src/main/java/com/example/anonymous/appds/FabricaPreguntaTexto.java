package com.example.anonymous.appds;

/**
 * Clase FabricaPreguntaTexto que implementa la interfaz ServicioPreguntas
 */
public class FabricaPreguntaTexto implements ServicioPreguntas {

    public Pregunta crearpregunta(){
        return new PreguntaTexto();
    }
}
