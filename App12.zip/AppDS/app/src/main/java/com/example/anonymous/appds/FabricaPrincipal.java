package com.example.anonymous.appds;

import android.content.Context;
import android.widget.Button;
import android.widget.TextView;

import com.example.anonymous.appds.Modelo.Dato;

/**
 * Clase FabricaPrincipal
 */
public class FabricaPrincipal {
    public static int  crearFabricaDePreguntas(ServicioPreguntas factory,Context cxt,Dato dat,TextView x,Button p1,Button p2,Button p3,Button p4){
        Pregunta pregun=factory.crearpregunta();
        return pregun.initPregunta(cxt,dat,x,p1,p2,p3,p4);
    }
}
