package com.example.anonymous.appds.Modelo;

import java.io.Serializable;

/**
 * Clase Dato
 */
public class Dato implements Serializable{
    private String tipo;
    private String tematica;
    private String enunciado;
    private String p1;
    private String p2;
    private String p3;
    private String p4;
    private String solucion;
    private String multimedia;

    Dato(String q,String a,String w,String e,String r,String t,String y,String u,String i){
        tipo=q;
        tematica=a;
        enunciado=w;
        p1=e;
        p2=r;
        p3=t;
        p4=y;
        solucion=u;
        multimedia=i;
    }

    public String get_Tipo(){
        return tipo;
    }
    public String get_enunciado(){
        return enunciado;
    }
    public String get_p1(){
        return p1;
    }
    public String get_p2(){
        return p2;
    }
    public String get_p3(){
        return p3;
    }
    public String get_p4(){
        return p4;
    }
    public String get_multimedia(){
        return multimedia;
    }
    public String get_solucion(){
        return solucion;
    }
}
