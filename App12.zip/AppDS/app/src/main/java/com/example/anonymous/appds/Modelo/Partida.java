package com.example.anonymous.appds.Modelo;

import android.database.Cursor;
import android.util.Log;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Clase Partida
 */
public class Partida implements Serializable{

    private ArrayList<Integer> preguntadas;
    private int total;
    private int acertadas;
    private String name;
    private int indice_ultima=0;
    private int time_total;
    private long time_ult;
    private ArrayList<Dato> preguntas;

    public Partida(){
        total=0;
        preguntadas=new ArrayList<>();
        name="default";
        acertadas=0;
        time_ult=30;
        time_total=0;
        preguntas=new ArrayList<>();
    }
    Partida(String x){
        total=0;
        preguntadas=new ArrayList<>();
        name=x;
        time_ult=30;
        time_total=0;
        preguntas=new ArrayList<>();
    }

    public void cargarPreguntas(Cursor x,int num){

        int cnt = x.getCount();//maximo de preguntas!

        for(int i=0; i<=num && num<cnt;++i) {
            int numero = 0;
            numero = new Double(Math.random() * cnt).intValue();
              //  Log.d("HolaMundo", "Entramos en bucle" + numero);
            while (preguntadas.contains(numero)) {
                //Log.d("HolaMundo", "Entramos en bucle" + numero);
                numero = new Double(Math.random() * cnt).intValue();
            }
            //  Log.d("numero añadido","es el -->"+numero);
            preguntadas.add(numero);
            x.moveToPosition(numero);
            Dato dat=new Dato(x.getString(0),x.getString(1),x.getString(2),x.getString(3),x.getString(4),x.getString(5),x.getString(6),x.getString(7),x.getString(8));
            preguntas.add(dat);
        }
    }

    public Dato get_pregunta(){
        Dato x= preguntas.get(total);
        total++;

        return x;
    }
    public void set_minusactual(){
        total--;
    }
    public String get_name(){return name;}
    public void set_name(String na){name=na;}
    public int get_total(){
        return total;
    }
    public void acertada(){acertadas++;}
    public int get_acertadas(){return acertadas;}
    public int get_time(){return time_total;}
    public void set_time(){time_total++;}
    public void set_time_ult(long t){time_ult=t;}
    public long get_time_ult(){return time_ult;}
    public int ultima(){return indice_ultima;}
}