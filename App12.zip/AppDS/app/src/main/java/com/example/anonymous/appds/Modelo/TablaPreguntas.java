package com.example.anonymous.appds.Modelo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.Scanner;

/**
 * Clase TablaPreguntas que gestiona la tabla de preguntas de la Base de Datos de la aplicacion
 */
public class TablaPreguntas {

    // Nombre de la tabla
    private final static String NAME = "Preguntas";

    // Objeto que utilizamos para acceder a la base de datos.
    private static SQLiteDatabase sqlDB;

    /**
     * Constructor
     *
     * @param sqlDB
     */
    public TablaPreguntas(SQLiteDatabase sqlDB) {
        this.sqlDB = sqlDB;
    }

    // Sentencia para crear la tabla en la BD.
    public final static String CREATE_TABLE ="CREATE TABLE if not exists "+NAME+" (tipo INTEGER,tematica TEXT, enunciado TEXT,p1 TEXT,p2 TEXT,p3 TEXT,p4 TEXT,solucion INTEGER,multimedia TEXT)";

    /**
     * Inserta una nueva pregunta en la tabla.
     *
     * @param tipo
     * @param tematica
     * @param enunciado
     * @param p1
     * @param p2
     * @param p3
     * @param p4
     * @param solucion
     * @param multimedia
     *
     * @return true si se inserta correctamente.
     */
    public static boolean insert(int tipo, String tematica, String enunciado, String p1,String p2,String p3,String p4,
                    int solucion,String multimedia) {

        String sql = "INSERT INTO "+NAME+" (tipo,tematica,enunciado,p1,p2,p3,p4,solucion,multimedia) " +
          "VALUES ('"+tipo+"',"+ tematica+ ","+enunciado+ ","+p1+ ","+p2+ ","+p3+ ","+p4+ ","+solucion+ ","+multimedia+ ")";

        sqlDB.execSQL(sql);
        return true;
    }

    /**
     * Devuelve el cursor con todos las tuplas de la Tabla
     *
     * @return Cursor
     */
    public static Cursor getTabla() {
        return sqlDB.rawQuery("SELECT * FROM "+NAME, null);
    }

    /**
     * Devuelve el nombre de la tabla.
     *
     * @return NAME
     */
    public String getName() {
        return NAME;
    }

    /**
     * Comprueba si la tabla contiene datos.
     *
     * @return true si no contiene datos
     */
    public static boolean isEmpty() {
        return sqlDB.rawQuery("SELECT * FROM "+NAME, null).getCount() == 0;
    }


    /**
     * Comprueba el número de datos que contiene la tabla.
     *
     * @return numero de registros de la Tabla
     */
    public int get_num() {
        return sqlDB.rawQuery("SELECT * FROM "+NAME, null).getCount();
    }

    public static void rellenar(Context ctx){// mejorar usando la clase de inserccion

        StringBuilder sb = new StringBuilder();

        int resID =  ctx.getResources().getIdentifier("database", "raw", ctx.getPackageName());
        Scanner sc = new Scanner( ctx.getResources().openRawResource(resID) );
        while(sc.hasNextLine()) {
            sb.append(sc.nextLine());
            sb.append('\n');
            if (sb.indexOf(";") != -1) {
                sqlDB.execSQL(sb.toString());
                sb.delete(0, sb.capacity());
            }
        }
    }
}
