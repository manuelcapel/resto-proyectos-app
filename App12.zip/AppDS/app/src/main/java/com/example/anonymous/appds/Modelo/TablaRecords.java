package com.example.anonymous.appds.Modelo;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

/**
 * Clase TablaPreguntas que gestiona la tabla de los records de la Base de Datos de la aplicacion
 */
public class TablaRecords {

    // Nombre de la tabla
    private final static String NAME = "Records";

    // Objeto que utilizamos para acceder a la base de datos.
    private static SQLiteDatabase sqlDB;

    /**
     * Constructor
     *
     * @param sqlDB
     */
    public TablaRecords(SQLiteDatabase sqlDB) {
        this.sqlDB = sqlDB;
    }

    // Sentencia para crear la tabla en la BD.
    public final static String CREATE_TABLE ="CREATE TABLE if not exists "+NAME+"(puesto INTEGER,tematica TEXT, nombre TEXT,puntos INTEGER,fallos INTEGER,tiempo INTEGER)";

    /**
     * Inserta una nueva tupla en la tabla solo si se ha establecido un nuevo record.
     *
     * @param nombre
     * @param tematica
     * @param puntos
     * @param tiempo
     *
     * @return true si se inserta correctamente.
     */
    public static boolean insert(String nombre, String tematica, int puntos,int fallos, int tiempo,int pos) {// aun no le insertamos tematica pues no lo tenemos aun organizao
        String sql = "INSERT INTO "+NAME+" (nombre,puntos,fallos, tiempo,puesto) VALUES ('"+nombre+"',"+ puntos+ ","+fallos+","+ tiempo+ ","+pos+")";
        sqlDB.execSQL(sql);
        return true;
    }

     /**
      * Inserta una nueva tupla en la tabla solo si se ha establecido un nuevo record.
      *
      * @param nombre
      * @param tematica
      * @param puntos
      * @param tiempo
      * @param pos que se actualiza
      *
      * @return true si se actualiza correctamente.
      */
     public static boolean actualizar(String nombre, String tematica, int puntos,int fallos, int tiempo,int pos) {// aun no le insertamos tematica pues no lo tenemos aun organizao
         String sql = "Update "+NAME+" set puesto="+pos+",nombre='"+nombre+"',puntos="+ puntos+",fallos="+fallos+",tiempo="+tiempo+" where puesto="+pos;
         sqlDB.execSQL(sql);
         return true;
     }
    /**
     * Devuelve el cursor con todos las tuplas de la Tabla
     *
     * @return Cursor
     */
    public static Cursor getTabla() {
        return sqlDB.rawQuery("SELECT * FROM "+NAME, null);
    }
     /**
      * Devuelve el cursor con los valores seleccionador por los parametros de todas las tuplas de la Tabla
      *
      * @param x
      * @param y
      * @param z
      *
      * @return Cursor
      */
     public static Cursor getTabla4(String x,String y, String z,String w) {
         return sqlDB.rawQuery("SELECT "+x+","+y+","+z+","+w+ " FROM "+NAME, null);
     }

    /**
     * Devuelve el nombre de la tabla.
     *
     * @return NAME
     */
    public String getName() {
        return NAME;
    }

    /**
     * Comprueba si la tabla contiene datos.
     *
     * @return true si no contiene datos
     */
    public static boolean isEmpty() {
        return sqlDB.rawQuery("SELECT * FROM "+NAME, null).getCount() == 0;
    }


     /**
      * Comprueba el número de datos que contiene la tabla.
      *
      * @return numero de registros de la Tabla
      */
     public static int get_num() {
         return sqlDB.rawQuery("SELECT * FROM "+NAME, null).getCount();
     }
}
