package com.example.anonymous.appds;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.widget.Button;
import android.widget.TextView;

import com.example.anonymous.appds.Controlador.ControladorBD;
import com.example.anonymous.appds.Modelo.Dato;
import com.example.anonymous.appds.Vista.Preguntas_activity;
import com.example.anonymous.appds.Vista.Records_activity;

import java.io.Serializable;

/**
 * Interfaz Pregunta
 */
public interface Pregunta{
    public int initPregunta(Context ctx,Dato dato,TextView t,Button p1,Button p2,Button p3,Button p4);

}
