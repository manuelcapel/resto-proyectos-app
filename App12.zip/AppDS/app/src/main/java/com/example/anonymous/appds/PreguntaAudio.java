package com.example.anonymous.appds;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.anonymous.appds.Modelo.Dato;

/**
 * Clase PreguntaAudio que implementa la interfaz Pregunta
 * Realizado por Juan anonymous García & Sergio García Molina
 */
public class PreguntaAudio implements Pregunta {

    @Override
    public int initPregunta(Context ctx, Dato dat,TextView t,Button p1,Button p2,Button p3,Button p4) {
       // Log.d("HolaMundo", "Entramos en bucle" + dat.get_enunciado());
        t.setText(dat.get_enunciado());
        t.setTextSize(20);
        t.setTextColor(Color.BLACK);
        int resID = ctx.getResources().getIdentifier(dat.get_multimedia(), "drawable", ctx.getPackageName());
        final MediaPlayer mp= MediaPlayer.create(ctx, resID);
        t.setBackgroundResource(R.drawable.audio);
        t.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mp.start();
            }
        });
        p1.setText(dat.get_p1());
        p2.setText(dat.get_p2());
        p3.setText(dat.get_p3());
        p4.setText(dat.get_p4());
        return Integer.parseInt(dat.get_solucion());
    }
}
