package com.example.anonymous.appds;

import android.content.Context;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import com.example.anonymous.appds.Modelo.Dato;

/**
 * Clase PreguntaImagen que implementa la interfaz Pregunta
 */
public class PreguntaImagen implements Pregunta  {

    @Override
    public int initPregunta(Context ctx,Dato dat,TextView t,Button p1,Button p2,Button p3,Button p4) {

        t.setText(dat.get_enunciado());
        int resID = ctx.getResources().getIdentifier(dat.get_multimedia(), "drawable", ctx.getPackageName());
       // Log.d("HolaMundo", "Entramos en bucle" + dat.get_enunciado()+"--"+dat.get_multimedia());
        t.setBackgroundResource(resID);
        p1.setText(dat.get_p1());
        p2.setText(dat.get_p2());
        p3.setText(dat.get_p3());
        p4.setText(dat.get_p4());
        return Integer.parseInt(dat.get_solucion());
    }

}
