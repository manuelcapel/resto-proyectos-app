package com.example.anonymous.appds;

import android.content.Context;
import android.graphics.Color;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import com.example.anonymous.appds.Modelo.Dato;

/**
 * Clase PreguntaTexto que implementa la interfaz Pregunta
 */
public class PreguntaTexto implements Pregunta  {

    Button p1= null;
    Button p2= null;
    Button p3= null;
    Button p4= null;
    TextView enunciado=null;

    @Override
    public int initPregunta(Context ctx,Dato dat,TextView t,Button p1,Button p2,Button p3,Button p4) {
        //Log.d("HolaMundo", "Entramos en bucle" + dat.get_enunciado() + "--" + dat.get_multimedia());
        t.setText(dat.get_enunciado());
        t.setTextSize(35);
        t.setTextColor(Color.BLACK);
        p1.setText(dat.get_p1());
        p2.setText(dat.get_p2());
        p3.setText(dat.get_p3());
        p4.setText(dat.get_p4());
        return Integer.parseInt(dat.get_solucion());
    }
}
