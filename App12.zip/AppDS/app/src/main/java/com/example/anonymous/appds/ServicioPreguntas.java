package com.example.anonymous.appds;

/**
 * Interfaz ServicioPreguntas
 */

public interface ServicioPreguntas {

    public Pregunta crearpregunta();
}
