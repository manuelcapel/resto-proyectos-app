package com.example.anonymous.appds.Vista;

import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.PersistableBundle;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.anonymous.appds.Controlador.ControladorBD;
import com.example.anonymous.appds.Controlador.ControladorPartida;
import com.example.anonymous.appds.R;

/**
 * Clase MainActivity
 */
public class MainActivity extends ActionBarActivity {

    private Button inicio;
    private Button records;
    private ControladorBD bd;
    private EditText usuario;
    private Button enlace2,enlace1,enlace3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inicio = (Button) findViewById(R.id.button);
        records = (Button) findViewById(R.id.button2);
        enlace2 = (Button) findViewById(R.id.button3);
        enlace1 = (Button) findViewById(R.id.button4);
        enlace3 = (Button) findViewById(R.id.button5);
        usuario=(EditText) findViewById(R.id.editText);


        //abrimos conecxion con la base datos
        bd = new ControladorBD(this);

        usuario.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                usuario.setText("");
            }
        });


        inicio.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                bd.open();

                Cursor cursorcito = bd.getPreguntas();

                ControladorPartida partida= new ControladorPartida();
                partida.cargarPreguntas(cursorcito,20);
                bd.close();

                partida.introducir_usuario(usuario.getText().toString());
                Intent intent = new Intent(MainActivity.this, Preguntas_activity.class);
                intent.putExtra("parametro",partida);
                startActivity(intent);
            }
        });

        records.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Records_activity.class);
                startActivity(intent);
            }
        });
        enlace2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                Uri data = Uri.parse("https://play.google.com/store/apps/details?id=com.etermax.preguntados.lite&hl=es");
                intent.setData(data);
                startActivity(intent);
            }
        });

        enlace1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                Uri data = Uri.parse("https://play.google.com/store/apps/details?id=pasa.palabras&hl=es");
                intent.setData(data);
                startActivity(intent);
            }
        });
        enlace3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                Uri data = Uri.parse("https://play.google.com/store/apps/details?id=com.creactive.quemquersermilionario.millonario.lite&hl=es");
                intent.setData(data);
                startActivity(intent);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
