package com.example.anonymous.appds.Vista;
import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;

import android.os.CountDownTimer;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;
import android.content.Intent;

import com.example.anonymous.appds.Controlador.ControladorBD;
import com.example.anonymous.appds.Controlador.ControladorPartida;
import com.example.anonymous.appds.FabricaPreguntaAudio;
import com.example.anonymous.appds.FabricaPreguntaImagen;
import com.example.anonymous.appds.FabricaPreguntaTexto;
import com.example.anonymous.appds.FabricaPrincipal;
import com.example.anonymous.appds.Modelo.Dato;
import com.example.anonymous.appds.R;
/**
 * Clase Preguntas_activity
 */
public class Preguntas_activity extends Activity {

    private TextView enunciado;
    private TextView puntuacion;
    private TextView name;
    private TextView time;
    private Button p1;
    private Button p2;
    private Button p3;
    private Button p4;

    //crono!!
    private CountDownTimer timer;

    int solucion=0;

    private ProgressDialog pd = null;

    private ControladorPartida partida= new ControladorPartida();

    //para el sonido:
    public MediaPlayer mpfallo;
    public MediaPlayer mpacierto;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        this.pd = ProgressDialog.show(this, "Procesando", "Espere unos segundos...", true, false);
        if (savedInstanceState == null) {
            recogerparametro();
            comienza(30);
        }
        else {
            restoreMe(savedInstanceState);
            comienza((int) partida.get_tiempo_ult());
        }

       // sleep(5000);
        this.pd.dismiss();

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preguntas_activity);

        //Obtenemos las referencias a los controles
        p1 = (Button) findViewById(R.id.p1);
        p2 = (Button) findViewById(R.id.p2);
        p3 = (Button) findViewById(R.id.p3);
        p4 = (Button) findViewById(R.id.p4);
        enunciado = (TextView) findViewById(R.id.textView);
        puntuacion=(TextView) findViewById(R.id.textView7);
        name=(TextView) findViewById(R.id.textView2);
        time=(TextView) findViewById(R.id.textView8);
        //asigno los sonidos
        mpacierto= MediaPlayer.create(this,R.drawable.acierto);
        mpfallo= MediaPlayer.create(this,R.drawable.fallo);

        Dato pregunt = partida.get_pregunta();

        name.setText(partida.get_usuario());
            puntuacion.setText("Total/Acertadas: "+(partida.get_total()-1)+"/"+partida.get_aciertos());

        //Creamos la pregunta usando el patrón Factoria Abstracta
        switch(Integer.parseInt(pregunt.get_Tipo())){
            case 0:
                solucion=FabricaPrincipal.crearFabricaDePreguntas(new FabricaPreguntaTexto(),this,pregunt,enunciado,p1,p2,p3,p4);
                break;
            case 1:
                solucion=FabricaPrincipal.crearFabricaDePreguntas(new FabricaPreguntaImagen(),this,pregunt,enunciado,p1,p2,p3,p4);
                break;
            case 2:
                solucion=FabricaPrincipal.crearFabricaDePreguntas(new FabricaPreguntaAudio(),this,pregunt,enunciado,p1,p2,p3,p4);
                break;
       }
        //solucion=Integer.parseInt(pregunt.get_solucion());
        p1.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                p2.setEnabled(false);
                p3.setEnabled(false);
                p4.setEnabled(false);
                if (0 == solucion){
                    mpacierto.start();
                    p1.setBackgroundResource(R.drawable.boton_redondo_v);
                    partida.añadir_acierto();
                }
                else {
                    p1.setBackgroundResource(R.drawable.boton_redondo_f);
                    mpfallo.start();
                } //else
                lanzarActivity();
            }
        });
        p2.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                p1.setEnabled(false);
                p3.setEnabled(false);
                p4.setEnabled(false);
                if (1 == solucion) {
                    p2.setBackgroundResource(R.drawable.boton_redondo_v);
                    mpacierto.start();
                    partida.añadir_acierto();

                }
                else {
                    p2.setBackgroundResource(R.drawable.boton_redondo_f);
                    mpfallo.start();
                }
                lanzarActivity();
            }
        });
        p3.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                p2.setEnabled(false);
                p1.setEnabled(false);
                p4.setEnabled(false);
                if (2 == solucion) {
                    p3.setBackgroundResource(R.drawable.boton_redondo_v);
                    mpacierto.start();
                    partida.añadir_acierto();
                }
                else {
                    p3.setBackgroundResource(R.drawable.boton_redondo_f);
                    mpfallo.start();
                }
                lanzarActivity();
            }
        });
        p4.setOnClickListener(new OnClickListener() {
            public void onClick(View v) {
                p2.setEnabled(false);
                p3.setEnabled(false);
                p1.setEnabled(false);
                if (3 == solucion) {
                    p4.setBackgroundResource(R.drawable.boton_redondo_v);
                    mpacierto.start();
                    partida.añadir_acierto();
                }
                else {
                    p4.setBackgroundResource(R.drawable.boton_redondo_f);
                    mpfallo.start();
                }
                lanzarActivity();
            }
        });
    }// END ON CREATE

    @Override
    protected void onSaveInstanceState(Bundle outState){
        timer.cancel();
        partida.mantenerPregunta();
        outState.putSerializable("parametro", partida);
        super.onSaveInstanceState(outState);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        timer.cancel();
        return super.onKeyDown(keyCode, event);
    }

    private void restoreMe(Bundle state){
        partida=null;

        if (state!=null) {
            ControladorPartida pregun = (ControladorPartida) state.getSerializable("parametro");

            if (pregun!=null) {
                partida=pregun;
            }
        }
    }

    public void lanzarActivity(View v, String texto) {
        timer.cancel();
        Intent intent = new Intent(this, Preguntas_activity.class);
        //intent.putExtra("parametro", "string");
        startActivity(intent);
    }
    public void lanzarActivity() {
        timer.cancel();
        if(partida.get_total()<20) {
            Intent intent = new Intent(this, Preguntas_activity.class);
            intent.putExtra("parametro", partida);
            finish();
            startActivity(intent);
        }
        else{
            ControladorBD bd = new ControladorBD(this);
            bd.open();
            bd.RecordsInsert(partida.get_usuario(),null,partida.get_aciertos(),partida.get_fallos(),partida.get_tiempo());
            Intent intent = new Intent(this, Records_activity.class);
            bd.close();      //controlado
            finish();
            startActivity(intent);
        }
    }

    private void recogerparametro() {
        partida = (ControladorPartida) getIntent().getExtras().getSerializable("parametro");
    }

    private void comienza(int x) {
        // Iniciamos el timer, como parámetros pasaremos el número de
        // minutos que hemos establecido en la aplicación, multiplicado
        // por 60 y por 1000 para obtener el valor en milisegundos, el
        // segúndo parámetro es el que nos dirá cada cuánto se produce el
        // "tick".
        timer = new CountDownTimer(x* 1000, 1000) {
            // Al declarar un nuevo CountDownTimer nos obliga a
            // sobreescribir algunos de sus eventos.
            @Override
            public void onTick(long millisUntilFinished) {
                // Este método se lanza por cada lapso de tiempo
                // transcurrido,
                if((millisUntilFinished / 1000)<15)
                    time.setTextColor(Color.RED);

                time.setText(String.valueOf(millisUntilFinished / 1000) + "s");
                partida.set_tiempo();
                partida.set_tiempo_ult(millisUntilFinished / 1000);
            }

            @Override
            public void onFinish() {
                // Este método se lanza cuando finaliza el contador.
                // Indicamos que la aplicación ya no está funcionando.
                switch (solucion){
                    case 0:{
                        p1.setBackgroundResource(R.drawable.boton_redondo_v);
                        p2.setBackgroundResource(R.drawable.boton_redondo_f);
                        p3.setBackgroundResource(R.drawable.boton_redondo_f);
                        p4.setBackgroundResource(R.drawable.boton_redondo_f);
                        mpfallo.start();
                        break;
                    }

                    case 1:{
                        p1.setBackgroundResource(R.drawable.boton_redondo_f);
                        p2.setBackgroundResource(R.drawable.boton_redondo_v);
                        p3.setBackgroundResource(R.drawable.boton_redondo_f);
                        p4.setBackgroundResource(R.drawable.boton_redondo_f);
                        mpfallo.start();
                        break;
                    }

                    case 2:{
                        p1.setBackgroundResource(R.drawable.boton_redondo_f);
                        p2.setBackgroundResource(R.drawable.boton_redondo_f);
                        p3.setBackgroundResource(R.drawable.boton_redondo_v);
                        p4.setBackgroundResource(R.drawable.boton_redondo_f);
                        mpfallo.start();
                        break;
                    }

                    case 3:{
                        p1.setBackgroundResource(R.drawable.boton_redondo_f);
                        p2.setBackgroundResource(R.drawable.boton_redondo_f);
                        p3.setBackgroundResource(R.drawable.boton_redondo_f);
                        p4.setBackgroundResource(R.drawable.boton_redondo_v);
                        mpfallo.start();
                        break;
                    }
                }
                lanzarActivity();

                // Mostramos el aviso de que ha finalizado el tiempo.
             /*   Toast.makeText(acti.this,
                        getResources().getString(R.string.tiem),
                        Toast.LENGTH_SHORT).show();*/
            }
        };
        // Una vez configurado el timer, lo iniciamos.
        timer.start();

    }
}