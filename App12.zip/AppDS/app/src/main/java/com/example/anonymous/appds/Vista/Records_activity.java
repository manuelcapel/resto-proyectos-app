package com.example.anonymous.appds.Vista;

import android.app.Activity;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.TextView;

import com.example.anonymous.appds.Controlador.ControladorBD;
import com.example.anonymous.appds.R;

/**
 * Clase Records_activity
 */

public class Records_activity extends Activity {

    private TextView a1,n1,f1,t1;
    private TextView a2,n2,f2,t2;
    private TextView a3,n3,f3,t3;
    private TextView a4,n4,f4,t4;
    private TextView a5,n5,f5,t5;
    private TextView a6,n6,f6,t6;
    private TextView a7,n7,f7,t7;
    private TextView a8,n8,f8,t8;
    private TextView a9,n9,f9,t9;
    private TextView a10,n10,f10,t10;

    //private SQLiteDatabase db;


    private ControladorBD bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_records_activity);

        a1=(TextView) findViewById(R.id.a1);
        n1=(TextView) findViewById(R.id.n1);
        f1=(TextView) findViewById(R.id.f1);
        t1=(TextView) findViewById(R.id.t1);

        a2=(TextView) findViewById(R.id.a2);
        n2=(TextView) findViewById(R.id.n2);
        f2=(TextView) findViewById(R.id.f2);
        t2=(TextView) findViewById(R.id.t2);

        a3=(TextView) findViewById(R.id.a3);
        n3=(TextView) findViewById(R.id.n3);
        f3=(TextView) findViewById(R.id.f3);
        t3=(TextView) findViewById(R.id.t3);

        a4=(TextView) findViewById(R.id.a4);
        n4=(TextView) findViewById(R.id.n4);
        f4=(TextView) findViewById(R.id.f4);
        t4=(TextView) findViewById(R.id.t4);

        a5=(TextView) findViewById(R.id.a5);
        n5=(TextView) findViewById(R.id.n5);
        f5=(TextView) findViewById(R.id.f5);
        t5=(TextView) findViewById(R.id.t5);

        a6=(TextView) findViewById(R.id.a6);
        n6=(TextView) findViewById(R.id.n6);
        f6=(TextView) findViewById(R.id.f6);
        t6=(TextView) findViewById(R.id.t6);

        a7=(TextView) findViewById(R.id.a7);
        n7=(TextView) findViewById(R.id.n7);
        f7=(TextView) findViewById(R.id.f7);
        t7=(TextView) findViewById(R.id.t7);

        a8=(TextView) findViewById(R.id.a8);
        n8=(TextView) findViewById(R.id.n8);
        f8=(TextView) findViewById(R.id.f8);
        t8=(TextView) findViewById(R.id.t8);

        a9=(TextView) findViewById(R.id.a9);
        n9=(TextView) findViewById(R.id.n9);
        f9=(TextView) findViewById(R.id.f9);
        t9=(TextView) findViewById(R.id.t9);

        a10=(TextView) findViewById(R.id.a10);
        n10=(TextView) findViewById(R.id.n10);
        f10=(TextView) findViewById(R.id.f10);
        t10=(TextView) findViewById(R.id.t10);

     //   db = usdbh.getWritableDatabase();

        //abrimos conecxion con la base datos
        bd = new ControladorBD(this);
        bd.open();

        //Cursor cursorcito = db.rawQuery("SELECT nombre,puntos,tiempo FROM Records0", null);

        Cursor cursorcito= bd.getRecords("nombre","puntos","fallos","tiempo");

        if(!bd.RecordsIsEmpty()) {
            for (int i = 0; i < cursorcito.getCount(); i++) {
                cursorcito.moveToPosition(i);
                switch (i) {
                    case 0: {
                        n1.setText(cursorcito.getString(0));
                        a1.setText(cursorcito.getString(1));
                        f1.setText(cursorcito.getString(2));
                        t1.setText(cursorcito.getString(3));
                        break;
                    }
                    case 1: {
                        n2.setText(cursorcito.getString(0));
                        a2.setText(cursorcito.getString(1));
                        f2.setText(cursorcito.getString(2));
                        t2.setText(cursorcito.getString(3));
                        break;
                    }
                    case 2: {
                        n3.setText(cursorcito.getString(0));
                        a3.setText(cursorcito.getString(1));
                        f3.setText(cursorcito.getString(2));
                        t3.setText(cursorcito.getString(3));
                        break;
                    }
                    case 3: {
                        n4.setText(cursorcito.getString(0));
                        a4.setText(cursorcito.getString(1));
                        f4.setText(cursorcito.getString(2));
                        t4.setText(cursorcito.getString(3));
                        break;
                    }
                    case 4: {
                        n5.setText(cursorcito.getString(0));
                        a5.setText(cursorcito.getString(1));
                        f5.setText(cursorcito.getString(2));
                        t5.setText(cursorcito.getString(3));
                        break;
                    }
                    case 5: {
                        n6.setText(cursorcito.getString(0));
                        a6.setText(cursorcito.getString(1));
                        f6.setText(cursorcito.getString(2));
                        t6.setText(cursorcito.getString(3));
                        break;
                    }
                    case 6: {
                        n7.setText(cursorcito.getString(0));
                        a7.setText(cursorcito.getString(1));
                        f7.setText(cursorcito.getString(2));
                        t7.setText(cursorcito.getString(3));
                        break;
                    }
                    case 7: {
                        n8.setText(cursorcito.getString(0));
                        a8.setText(cursorcito.getString(1));
                        f8.setText(cursorcito.getString(2));
                        t8.setText(cursorcito.getString(3));
                        break;
                    }
                    case 8: {
                        n9.setText(cursorcito.getString(0));
                        a9.setText(cursorcito.getString(1));
                        f9.setText(cursorcito.getString(2));
                        t9.setText(cursorcito.getString(3));
                        break;
                    }
                    case 9: {
                        n10.setText(cursorcito.getString(0));
                        a10.setText(cursorcito.getString(1));
                        f10.setText(cursorcito.getString(2));
                        t10.setText(cursorcito.getString(3));
                        break;
                    }
                }
            }//end for
        }//end !bd.RecordsIsEmpty
        bd.close();
    }
}
