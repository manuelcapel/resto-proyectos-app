package com.games.autor.ds_juego;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class DBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "BD_QUIZ";
    Context context;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME, null, 14);
    }

    public void onCreate(SQLiteDatabase db) {
        //Creamos la tabla de preguntas
        String insert_table_preguntas = "CREATE TABLE PREGUNTAS " +
                "(tipo INTEGER," +
                "pregunta TEXT," +
                "respuesta1 TEXT, " +
                "respuesta2 TEXT, " +
                "respuesta3 TEXT, " +
                "respuesta4 TEXT, " +
                "imagen TEXT, " +
                "sonido TEXT)";
        db.execSQL(insert_table_preguntas);

        //Leemos el archivo de preguntas
        Log.d("debug", "Creando la Base de Datos");
    }

    public void borrarPreguntas()
    {
        SQLiteDatabase db = this.getWritableDatabase();
        db.execSQL("DELETE FROM PREGUNTAS");
    }


    public void insertarPregunta(Pregunta pregunta) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("tipo", pregunta.getTipo());
        values.put("pregunta",pregunta.getEnunciado());
        values.put("respuesta1", pregunta.getRespuesta1());
        values.put("respuesta2", pregunta.getRespuesta2());
        values.put("respuesta3", pregunta.getRespuesta3());
        values.put("respuesta4", pregunta.getRespuesta4());
        values.put("imagen", pregunta.getImagen());
        values.put("sonido", pregunta.getSonido());
        // Inserting Row
        db.insert("PREGUNTAS", null, values);
        Log.d("debug", "Insertada pregunta a las "+new Date().toString());
        db.close(); // Closing database connection
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Eliminamos la tabla existente
        db.execSQL("DROP TABLE IF EXISTS PREGUNTAS");
        // Creamos de nuevo la tabla
        onCreate(db);
    }

    public List<Pregunta> obtenerPreguntas() {
        List<Pregunta> preguntasList = new ArrayList<Pregunta>();
        // Select All Query
        String selectQuery = "SELECT  * FROM Preguntas";

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Pregunta p = new Pregunta();
                p.setTipo(Integer.parseInt(cursor.getString(0)));
                p.setEnunciado(cursor.getString(1));
                p.setRespuesta1(cursor.getString(2));
                p.setRespuesta2(cursor.getString(3));
                p.setRespuesta3(cursor.getString(4));
                p.setRespuesta4(cursor.getString(5));
                p.setImagen(cursor.getString(6));
                p.setSonido(cursor.getString(7));
                // Adding contact to list
                preguntasList.add(p);
            } while (cursor.moveToNext());
        }
        // return contact list
        return preguntasList;
    }

    public void LecturaDeFicheroBD(Context c)
    {
        StringBuilder sb = new StringBuilder();
        String[] pregunta;
        Scanner sc = new Scanner( c.getResources().openRawResource(R.raw.database) );
        while(sc.hasNextLine()) {
            pregunta = sc.nextLine().split(";");
            switch(pregunta[0].toString())
            {
                case "0":
                    insertarPregunta(new Pregunta(Integer.parseInt(pregunta[0].toString()), pregunta[1].toString(), pregunta[2].toString(), pregunta[3].toString(), pregunta[4].toString(), pregunta[5].toString(), "", ""));
                    break;
                case "1":
                    insertarPregunta(new Pregunta(Integer.parseInt(pregunta[0].toString()), pregunta[1].toString(), pregunta[2].toString(), pregunta[3].toString(), pregunta[4].toString(), pregunta[5].toString(), pregunta[6].toString(), ""));
                    break;
                case "2":
                    insertarPregunta(new Pregunta(Integer.parseInt(pregunta[0].toString()), pregunta[1].toString(), pregunta[2].toString(), pregunta[3].toString(), pregunta[4].toString(), pregunta[5].toString(), "", pregunta[7].toString()));
                    break;
            }

        }
    }




}
