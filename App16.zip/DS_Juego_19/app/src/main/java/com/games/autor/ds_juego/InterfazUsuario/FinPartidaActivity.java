package com.games.autor.ds_juego.InterfazUsuario;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.games.autor.ds_juego.Partida;
import com.games.autor.ds_juego.Puntuaciones;
import com.games.autor.ds_juego.R;

public class FinPartidaActivity extends Activity {
    MediaPlayer mediaPlayer;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finpartida);

        Partida p = Partida.getInstance();
        float resultado = p.ObtenerPorcentajeAcertadas();


        TextView tv = (TextView) findViewById(R.id.resultado_cadena);
        tv.setText("Eres un "+String.format("%.2f", resultado)+"% de iluminati");
        ImageView im = (ImageView) findViewById(R.id.resultado_imagen);
        im.setImageResource(R.drawable.iluminati2);
        String sonido_resultado = "";
        if(resultado<=20)//Sonido malo
            sonido_resultado = "res20";
        else if(resultado <= 40)//Sonido intermedio
            sonido_resultado = "res40";
        else if(resultado <= 60)
            sonido_resultado = "res60";
        else
            sonido_resultado = "res100";
        int sonidoResource = getResources().getIdentifier("raw/"+sonido_resultado, null, getPackageName());
        mediaPlayer = MediaPlayer.create(this.getApplicationContext(), sonidoResource);
        mediaPlayer.start();

        Puntuaciones puntos = new Puntuaciones(this.getApplicationContext());
        puntos.Agregar_puntuacion(String.format("%.2f", resultado));
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setMessage("¿Que desea realizar?");
        builder.setPositiveButton("Nueva partida", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent nextScreen = new Intent(getApplicationContext(), PreguntasActivity.class);
                startActivity(nextScreen);
                Partida.getInstance().NuevaPartida();
                finish();
            }
        });
        builder.setNegativeButton("Ir a menu",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent nextScreen = new Intent(getApplicationContext(), MenuActivity.class);
                startActivity(nextScreen);
                finish();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }
}
