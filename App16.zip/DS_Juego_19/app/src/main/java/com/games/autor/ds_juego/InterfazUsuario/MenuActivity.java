package com.games.autor.ds_juego.InterfazUsuario;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import com.games.autor.ds_juego.DBHelper;
import com.games.autor.ds_juego.Partida;
import com.games.autor.ds_juego.Pregunta;
import com.games.autor.ds_juego.R;

import java.util.ArrayList;
import java.util.List;

public class MenuActivity extends Activity {
    DBHelper bd = new DBHelper(this);
    List<Pregunta> listado = new ArrayList<Pregunta>();
    Partida p;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
        InicializarJuego();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    /** Called when the user clicks the Send button */
    public void iniciarJuego(View view) {
        Intent intent = new Intent(this, PreguntasActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.fade_in, R.anim.fade_out);
        NuevaPartida();
        finish();
    }

    public void iniciarOtros(View view) {
        Intent intent2 = new Intent(this, OtrosActivity.class);
        startActivity(intent2);
        finish();

    }

    public void iniciarResultados(View view) {
        Intent intent2 = new Intent(this, ResultadosActivity.class);
        startActivity(intent2);
        finish();

    }

    private void InicializarJuego()
    {
        bd.borrarPreguntas();
        bd.LecturaDeFicheroBD(this.getApplicationContext());
        listado = bd.obtenerPreguntas();
    }

    private void NuevaPartida()
    {
        p = Partida.getInstance();
        if(p.AgregarPreguntas(listado))
            p.NuevaPartida();
    }



    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setMessage("¿Desea salir?");
        builder.setPositiveButton("Si", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setNegativeButton("No",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }


}
