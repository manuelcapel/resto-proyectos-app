package com.games.autor.ds_juego.InterfazUsuario;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.webkit.WebView;

import com.games.autor.ds_juego.R;

public class OtrosActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_otros);
        WebView webview = (WebView) findViewById(R.id.wv1);
        webview.loadUrl("https://play.google.com/store/apps/details?id=com.undanet.desafiomaldini");
    }

    @Override
    public void onBackPressed() {
        Intent nextScreen = new Intent(getApplicationContext(), MenuActivity.class);
        startActivity(nextScreen);
        finish();
    }
}
