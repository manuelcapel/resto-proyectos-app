package com.games.autor.ds_juego.InterfazUsuario;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import com.games.autor.ds_juego.Partida;
import com.games.autor.ds_juego.Pregunta;
import com.games.autor.ds_juego.R;

import java.util.ArrayList;
import java.util.Collections;

public class PreguntasActivity extends Activity {
    Pregunta pregunta;
    Partida p;
    Button b;
    String respuesta_correcta;
    private double startTime = 0;
    private double finalTime = 0;
    public static int oneTimeOnly = 0;
    private Handler myHandler = new Handler();
    private MediaPlayer mediaPlayer = new MediaPlayer();
    private MediaPlayer media = new MediaPlayer();
    private SeekBar seekbar;
    LinearLayout ll;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pregunta);
        ll = (LinearLayout) findViewById(R.id.reproductor);
        ll.setVisibility(View.INVISIBLE);
        ArrayList<Integer> ids = new ArrayList<Integer>();
        ids.add(R.id.res1);
        ids.add(R.id.res2);
        ids.add(R.id.res3);
        ids.add(R.id.res4);
        Collections.shuffle(ids);

        seekbar = (SeekBar) findViewById(R.id.proceso);
        p = Partida.getInstance();
        pregunta = p.siguientePregunta();

        if(pregunta != null) {
            respuesta_correcta = pregunta.getRespuesta1();
            TextView tv = (TextView) findViewById(R.id.enun);
            tv.setText(pregunta.getEnunciado());
            if(pregunta.getTipo()== 1)//Si son de tipo imagen
            {
                String uri = "drawable/"+pregunta.getImagen();
                int imageResource = getResources().getIdentifier(uri, null, getPackageName());
                Drawable image = getResources().getDrawable(imageResource);
                tv.setCompoundDrawablesWithIntrinsicBounds(null, null, null, image);
            }
            else if(pregunta.getTipo()==2)//Si son de tipo sonido
            {
                ll.setVisibility(View.VISIBLE);
                int sonidoResource = getResources().getIdentifier("raw/"+pregunta.getSonido(), null, getPackageName());
                mediaPlayer = MediaPlayer.create(this.getApplicationContext(),sonidoResource);
            }
            int i = 1;
            for (Integer id : ids) {
                b = (Button) findViewById(id.intValue());
                b.setText(pregunta.getRespuesta(i));
                i++;
                b.setOnClickListener(new View.OnClickListener() {
                    public void onClick(View arg0) {
                            Intent nextScreen = new Intent(getApplicationContext(), PreguntasActivity.class);
                            startActivity(nextScreen);
                        //if(pregunta.getTipo()==2)
                           // terminarMedia(mediaPlayer);
                        Button bt = (Button) arg0;
                            if (bt.getText().toString() == respuesta_correcta) {
                                p.SumarAcierto();
                                arg0.setBackgroundColor(Color.GREEN);
                                media = MediaPlayer.create(getApplicationContext(),R.raw.correct);
                                media.start();
                            } else {
                                arg0.setBackgroundColor(Color.RED);
                                media = MediaPlayer.create(getApplicationContext(),R.raw.incorrect);
                                media.start();
                            }
                        //terminarMedia(media);
                        finish();

                    }
                });
            }
        }
        else
        {
            Intent nextScreen = new Intent(getApplicationContext(), FinPartidaActivity.class);
            startActivity(nextScreen);
            finish();
        }
    }

    private void terminarMedia(MediaPlayer m)
    {
        m.stop();
        m.reset();
    }

    public void play(View view){
        Toast.makeText(getApplicationContext(), R.string.Reproduciendo_sonido,Toast.LENGTH_SHORT).show();

        mediaPlayer.start();

        finalTime = mediaPlayer.getDuration();
        startTime = mediaPlayer.getCurrentPosition();
        if(oneTimeOnly == 0){
            seekbar.setMax((int) finalTime);
            oneTimeOnly = 1;
        }

        seekbar.setProgress((int) startTime);
        myHandler.postDelayed(UpdateSongTime, 100);
        ImageButton ib = (ImageButton) findViewById(R.id.play_sound);
        ib.setImageResource(android.R.drawable.ic_media_pause);
    }

    private Runnable UpdateSongTime = new Runnable() {
        public void run() {
            startTime = mediaPlayer.getCurrentPosition();
            seekbar.setProgress((int)startTime);
            myHandler.postDelayed(this, 100);
            if(startTime > finalTime-100)
            {
                ImageButton ib = (ImageButton) findViewById(R.id.play_sound);
                ib.setImageResource(android.R.drawable.ic_media_play);
            }
        }
    };




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setMessage("¿Que desea realizar?");
        builder.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();
            }
        });
        builder.setNegativeButton("Terminar partida",new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Intent nextScreen = new Intent(getApplicationContext(), FinPartidaActivity.class);
                startActivity(nextScreen);
                finish();
            }
        });
        AlertDialog alert=builder.create();
        alert.show();
    }
}
