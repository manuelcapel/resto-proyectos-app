package com.games.autor.ds_juego.InterfazUsuario;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import com.games.autor.ds_juego.Puntuaciones;
import com.games.autor.ds_juego.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

public class ResultadosActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_resultados);
        CargarPuntuaciones(15);
    }

    private void CargarPuntuaciones(int cantidad_resultados)
    {
        Puntuaciones p  = new Puntuaciones(this.getApplicationContext());


        Map<Date,Float> lista_resultados =  p.getListResultados(cantidad_resultados);
        String puntuaciones = "";
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        for(Map.Entry<Date,Float> e : lista_resultados.entrySet())
        {
            puntuaciones +="Poder: "+String.format("%.2f", e.getValue())+"% - Fecha:"+sdf.format(e.getKey())+"\n\n";
        }
        TextView tv  = (TextView) findViewById(R.id.puntuaciones);
        tv.setText(puntuaciones);
    }

    @Override
    public void onBackPressed() {
                Intent nextScreen = new Intent(getApplicationContext(), MenuActivity.class);
                startActivity(nextScreen);
                finish();
    }
}
