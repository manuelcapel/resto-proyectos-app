package com.games.autor.ds_juego;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Partida {
    private List<Pregunta> listado = new ArrayList<Pregunta>();
    private List<Pregunta> preguntas_partida = new ArrayList<Pregunta>();
    private static Partida instance = null;
    private int acertadas;
    private Partida() {

    }
    public static Partida getInstance() {
        if(instance == null) {
            instance = new Partida();
        }
        return instance;
    }

    public boolean AgregarPreguntas(List<Pregunta> preguntas)
    {
        try
        {
            listado = preguntas;
            return true;
        }
        catch(Exception ex)
        {
            return false;
        }
    }

    //Baraja el liado de preguntas
    public boolean NuevaPartida()
    {
        try
        {
            if(listado.size()>0)
            {
                preguntas_partida.clear();
                preguntas_partida.addAll(listado);
                Collections.shuffle(preguntas_partida);
                acertadas=0;
                return true;
            }
            else
                return false;
        }
        catch(Exception ex)
        {
            return false;
        }
    }

    public Pregunta siguientePregunta()
    {
        if(preguntas_partida.size()>0) {
            Pregunta p = preguntas_partida.get(0);
            preguntas_partida.remove(0);
            return p;
        }
        return null;
    }

    public boolean quedanPreguntas()
    {
        if(preguntas_partida.size()>0)
            return true;
        return false;
    }

    public void SumarAcierto()
    {
        acertadas++;
    }

    public float ObtenerPorcentajeAcertadas()
    {
        return (100/(float) listado.size() )*(float) acertadas;
    }

}
