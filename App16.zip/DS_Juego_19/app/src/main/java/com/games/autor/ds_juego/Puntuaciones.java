package com.games.autor.ds_juego;

import android.content.Context;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStreamWriter;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.Scanner;
import java.util.TreeMap;

public class Puntuaciones {
    private String nombre_archivo = "puntuaciones6";
    private Map<Date,Float> lista_resultados = new TreeMap<Date,Float>();
    private Context c;
    public Puntuaciones(Context con){c=con;}

    public boolean Agregar_puntuacion(String puntuacion)
    {
        try {
            FileOutputStream fos = c.openFileOutput(nombre_archivo, Context.MODE_APPEND);
            OutputStreamWriter out = new OutputStreamWriter(fos);
            DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
            Date date = new Date();
            out.write(dateFormat.format(date).toString() + "&" + puntuacion +"\n");
            out.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    //Leemos el archivo y generamos un listado con las puntuaciones
    private boolean CargarPuntuaciones()
    {
        Scanner sc = null;
        try {
            sc = new Scanner(c.openFileInput(nombre_archivo));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return false;
        }
        if(sc == null)
            return false;
        else
        {
            while (sc.hasNextLine()) {
                String[] resultado = sc.nextLine().split("&");
                String cadena_fecha = resultado[0];
                String puntuacion = resultado[1];
                //DateFormat dateFormat = DateFormat.getDateInstance();
                SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                try {

                    Date d = sdf.parse(cadena_fecha);
                    puntuacion = puntuacion.replace(',', '.');
                    Float f = new Float(puntuacion);
                    lista_resultados.put(d,f);
                } catch (ParseException e) {
                    e.printStackTrace();
                    return false;
                }
            }
            return true;
        }
    }

    //Devuelve los n ultimos resultados
    public Map<Date,Float> getListResultados(int n_ultimas)
    {
        Map<Date,Float> lista_corta = new TreeMap<Date,Float>();
        if(CargarPuntuaciones()) {

        /*for(int i = 0; i<lista_resultados.size();i++)
        {
            if(n_ultimas>=i)
            {
                lista_corta.put()
            }
        }*/
            int c = 0;
            for (Map.Entry<Date, Float> r : lista_resultados.entrySet()) {
                if (c >= (lista_resultados.size()-n_ultimas) )
                {
                    Date d = r.getKey();
                    Float f = r.getValue();
                    lista_corta.put(d,f);
                    //DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm:ss");
                    //Log.d("debug", "Fecha: " + dateFormat.format(d).toString());
                }
                c++;
            }

        }
        return lista_corta;
    }

    //Devuelve todos los resultados
    public  Map<Date,Float> getListResultados(){return lista_resultados;}

}
