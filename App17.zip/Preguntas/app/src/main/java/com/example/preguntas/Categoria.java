package com.example.preguntas;

public enum Categoria {
	TECNOLOGIA,
	ENTRETENIMIENTO,
	CIENCIA,
	ARTE_Y_LITERATURA,
	DEPORTE
}
