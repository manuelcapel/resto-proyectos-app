package com.example.preguntas;

import java.util.TreeMap;

public class Contador {
	private TreeMap<Categoria, Integer> acertadasPorCategoria;
	private TreeMap<Categoria, Integer> falladasPorCategoria;
	private static Contador instance;

	private Contador() {
		acertadasPorCategoria = new TreeMap<>();
		falladasPorCategoria = new TreeMap<>();
		for (Categoria categoria : Categoria.values()) {
			acertadasPorCategoria.put(categoria, 0);
			falladasPorCategoria.put(categoria, 0);
		}
	}

	public static Contador getInstance() {
		if (instance == null) {
			instance = new Contador();
		}
		return instance;
	}

	public void acertada(Categoria categoria) {
		acertadasPorCategoria.put(categoria, acertadasPorCategoria.get(categoria) + 1);
	}

	public void fallada(Categoria categoria) {
		falladasPorCategoria.put(categoria, falladasPorCategoria.get(categoria) + 1);
	}

	public TreeMap<Categoria, Integer> getAcertadasPorCategoria() {
		return acertadasPorCategoria;
	}

	public TreeMap<Categoria, Integer> getFalladasPorCategoria() {
		return falladasPorCategoria;
	}
}
