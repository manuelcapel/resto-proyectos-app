package com.example.preguntas;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceActivity;
import android.preference.PreferenceManager;

import java.util.ArrayList;

public class Preferencias extends PreferenceActivity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getFragmentManager().beginTransaction().replace(android.R.id.content, new PreferenciasFragment()).commit();
	}


	public int cargarPreferencias(ArrayList<Categoria> categorias, ArrayList<TipoPregunta> tipos, Context context) {
		if (categorias == null) {
			categorias = new ArrayList<>();
		} else {
			categorias.clear();
		}
		if (tipos == null) {
			tipos = new ArrayList<>();
		} else {
			tipos.clear();
		}
		SharedPreferences preferencias = PreferenceManager.getDefaultSharedPreferences(context);
		//Categorias
		if (preferencias.getBoolean("tecnologia", true)) {
			categorias.add(Categoria.TECNOLOGIA);
		}
		if (preferencias.getBoolean("entretenimiento", true)) {
			categorias.add(Categoria.ENTRETENIMIENTO);
		}
		if (preferencias.getBoolean("ciencia", true)) {
			categorias.add(Categoria.CIENCIA);
		}
		if (preferencias.getBoolean("arte_y_literatura", true)) {
			categorias.add(Categoria.ARTE_Y_LITERATURA);
		}
		if (preferencias.getBoolean("deporte", true)) {
			categorias.add(Categoria.DEPORTE);
		}

		//Tipos de Pregunta
		tipos.add(TipoPregunta.NORMAL);

		if (preferencias.getBoolean("audio", true)) {
			tipos.add(TipoPregunta.AUDIO);
		}
		if (preferencias.getBoolean("imagen", true)) {
			tipos.add(TipoPregunta.IMAGEN);
		}

		//Número de Preguntas
		return Integer.parseInt(preferencias.getString("n_preguntas", "10"));
	}
}
