package com.example.preguntas;

import android.os.Bundle;
import android.preference.CheckBoxPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceScreen;
import android.widget.Toast;

public class PreferenciasFragment extends PreferenceFragment {

	private CheckBoxPreference preferencias[];

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		addPreferencesFromResource(R.xml.preferencias);
		inicializarCheckBoxes();
	}

	private void inicializarCheckBoxes() {
		preferencias = new CheckBoxPreference[5];
		preferencias[0] = (CheckBoxPreference) findPreference("tecnologia");
		preferencias[1] = (CheckBoxPreference) findPreference("entretenimiento");
		preferencias[2] = (CheckBoxPreference) findPreference("ciencia");
		preferencias[3] = (CheckBoxPreference) findPreference("arte_y_literatura");
		preferencias[4] = (CheckBoxPreference) findPreference("deporte");
	}

	@Override
	public boolean onPreferenceTreeClick(PreferenceScreen preferenceScreen, Preference preference) {
		String key = preference.getKey();
		boolean encontrada = false;
		for (int i = 0; i < preferencias.length && !encontrada; i++) {
			if (key.equals(preferencias[i].getKey())) {
				encontrada = true;
				if (contarActivas(i) == 0) {
					((CheckBoxPreference) preference).setChecked(true);
					Toast.makeText(preference.getContext(), "Debe haber una categoría marcada", Toast.LENGTH_LONG).show();
				}
			}
		}
		return super.onPreferenceTreeClick(preferenceScreen, preference);
	}

	private int contarActivas(int id) {
		int cont = 0;
		for (int i = 0; i < preferencias.length; i++) {
			if (i != id && preferencias[i].isChecked()) {
				cont++;
			}
		}
		return cont;
	}
}
