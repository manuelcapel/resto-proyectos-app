package com.example.preguntas;

public class Pregunta {
	private String enunciado;

	private String respuestaA;
	private String respuestaB;
	private String respuestaC;
	private String respuestaD;
	private String source;

	private Categoria categoria;
	private TipoPregunta tipoPregunta;

	public Pregunta(String enunciado, String respA, String respB, String respC, String respD, Categoria cat, TipoPregunta tipo, String src) {
		this.enunciado = enunciado;
		respuestaA = respA;
		respuestaB = respB;
		respuestaC = respC;
		respuestaD = respD;
		categoria = cat;
		tipoPregunta = tipo;
		source = src;
	}

	public String getEnunciado() {
		return enunciado;
	}

	public String getRespuestaA() {
		return respuestaA;
	}

	public String getRespuestaB() {
		return respuestaB;
	}

	public String getRespuestaC() {
		return respuestaC;
	}

	public String getRespuestaD() {
		return respuestaD;
	}

	public TipoPregunta getTipoPregunta() {
		return tipoPregunta;
	}

	public Categoria getCategoria() {
		return categoria;
	}

	public String getSource() {
		return source;
	}
}
