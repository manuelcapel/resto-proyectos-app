package com.example.preguntas;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class PreguntaBD extends SQLiteOpenHelper {

	private Context context;

	public PreguntaBD(Context context) {
		super(context, "Preguntas", null, 1);
		this.context = context;

	}

	public ArrayList<Pregunta> getPreguntas(ArrayList<Categoria> categorias, ArrayList<TipoPregunta> tipos, int max_preguntas) {
		ArrayList<Pregunta> preguntas_aux = new ArrayList<>();
		SQLiteDatabase db = getReadableDatabase();

		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.append("SELECT * FROM pregunta WHERE (categoria = " + categorias.get(0).ordinal());
		for (int i = 1; i < categorias.size(); i++) {
			stringBuilder.append(" OR categoria = " + categorias.get(i).ordinal());
		}
		stringBuilder.append(") AND (tipo = " + tipos.get(0).ordinal());
		for (int i = 1; i < tipos.size(); i++) {
			stringBuilder.append(" OR tipo = " + tipos.get(i).ordinal());
		}
		stringBuilder.append(")");

		Cursor cursor = db.rawQuery(stringBuilder.toString(), null);
		Pregunta p;
		while (cursor.moveToNext()) {
			p = new Pregunta(cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5), Categoria.values()[cursor.getInt(6)], TipoPregunta.values()[cursor.getInt(7)], cursor.getString(8));
			preguntas_aux.add(p);
		}
		cursor.close();
		db.close();
		Collections.shuffle(preguntas_aux);
		ArrayList<Pregunta> preguntas = new ArrayList<>();
		for (int i = 0; i < max_preguntas && i < preguntas_aux.size(); i++) {
			preguntas.add(preguntas_aux.get(i));
		}
		return preguntas;
	}

	@Override
	public void onCreate(SQLiteDatabase sqLiteDatabase) {
		StringBuilder sb = new StringBuilder();
		Scanner sc = new Scanner(context.getResources().openRawResource(R.raw.database));
		while (sc.hasNextLine()) {
			sb.append(sc.nextLine());
			sb.append('\n');
			if (sb.indexOf(";") != -1) {
				sqLiteDatabase.execSQL(sb.toString());
				sb.delete(0, sb.capacity() - 1);
			}
		}
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

	}
}
