package com.example.preguntas;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;


public class Preguntas extends Activity {

	private ArrayList<Pregunta> preguntas;
	private Pregunta preguntaActual;
	private int nPreguntasHechas;
	private String respuestaCorrecta;
	private Button opcA, opcB, opcC, opcD;
	private TextView enunciado;
	private ImageView imagen;
	private MediaPlayer mediaPlayer;
	private int MAXPREGUNTAS;
	private ImageView background;
	private MediaPlayer sonidoAcertado;
	private MediaPlayer sonidoFallado;
	private boolean jugando;
	private boolean reproduciendo;
	private Contador contador;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_preguntas);
		contador = Contador.getInstance();
		jugando = false;
	}

	@Override
	protected void onPause() {
		super.onPause();
		if (mediaPlayer != null) {
			reproduciendo = mediaPlayer.isPlaying();
			mediaPlayer.pause();
		}
	}

	@Override
	protected void onResume() {
		super.onResume();
		if (!jugando) {
			inicializar();
			cargarPreguntas();
			comenzarJuego();
		} else if (mediaPlayer != null && reproduciendo) {
			mediaPlayer.start();
		}
	}

	private void inicializar() {
		jugando = true;
		reproduciendo = false;
		opcA = (Button) findViewById(R.id.buttonA);
		opcB = (Button) findViewById(R.id.buttonB);
		opcC = (Button) findViewById(R.id.buttonC);
		opcD = (Button) findViewById(R.id.buttonD);
		enunciado = (TextView) findViewById(R.id.enunciado);
		imagen = (ImageView) findViewById(R.id.imagen);
		background = (ImageView) findViewById(R.id.background);
		sonidoAcertado = MediaPlayer.create(this, R.raw.acertado);
		sonidoFallado = MediaPlayer.create(this, R.raw.fallado);
	}

	private void cargarPreguntas() {
		ArrayList<Categoria> categorias = new ArrayList<>();
		ArrayList<TipoPregunta> tipos = new ArrayList<>();

		Preferencias preferencias = new Preferencias();
		MAXPREGUNTAS = preferencias.cargarPreferencias(categorias, tipos, this);

		PreguntaBD bd = new PreguntaBD(this);
		preguntas = bd.getPreguntas(categorias, tipos, MAXPREGUNTAS);
	}

	private void comenzarJuego() {
		Collections.shuffle(preguntas);
		nPreguntasHechas = 0;
		hacerPregunta();
	}

	private void hacerPregunta() {

		if (nPreguntasHechas < MAXPREGUNTAS && nPreguntasHechas < preguntas.size()) {

			preguntaActual = preguntas.get(nPreguntasHechas);

			habilitarBotones(true);
			ocultarImagen();
			setBackground();

			if (preguntaActual.getTipoPregunta() == TipoPregunta.AUDIO) {
				cargarAudio();
			} else if (preguntaActual.getTipoPregunta() == TipoPregunta.IMAGEN) {
				cargarImagen(preguntaActual.getSource());
			}

			respuestaCorrecta = preguntaActual.getRespuestaA();

			enunciado.setText(preguntaActual.getEnunciado());

			ArrayList<String> respuestas = new ArrayList<>();
			respuestas.add(preguntaActual.getRespuestaA());
			respuestas.add(preguntaActual.getRespuestaB());
			respuestas.add(preguntaActual.getRespuestaC());
			respuestas.add(preguntaActual.getRespuestaD());
			Collections.shuffle(respuestas);

			opcA.setText(respuestas.get(0));
			opcB.setText(respuestas.get(1));
			opcC.setText(respuestas.get(2));
			opcD.setText(respuestas.get(3));
			nPreguntasHechas++;
		} else {

			finish();
		}
	}

	private void setBackground() {
		if (preguntaActual.getCategoria() == Categoria.CIENCIA) {
			background.setBackgroundResource(R.drawable.pregunta_texto_ciencia);
		} else if (preguntaActual.getCategoria() == Categoria.ARTE_Y_LITERATURA) {
			background.setBackgroundResource(R.drawable.pregunta_texto_arte_y_literatura);
		} else if (preguntaActual.getCategoria() == Categoria.DEPORTE) {
			background.setBackgroundResource(R.drawable.pregunta_texto_deportes);
		} else if (preguntaActual.getCategoria() == Categoria.ENTRETENIMIENTO) {
			background.setBackgroundResource(R.drawable.pregunta_texto_entretenimiento);
		} else if (preguntaActual.getCategoria() == Categoria.TECNOLOGIA) {
			background.setBackgroundResource(R.drawable.pregunta_texto_tecnologia);
		}
	}

	private boolean comprobarRespuesta(String respuesta) {
		return respuestaCorrecta.equals(respuesta);
	}

	private void ocultarImagen() {
		imagen.setVisibility(View.GONE);
	}

	private void habilitarBotones(boolean habilitar) {
		opcB.setClickable(habilitar);
		opcA.setClickable(habilitar);
		opcC.setClickable(habilitar);
		opcD.setClickable(habilitar);
	}

	private void cargarAudio() {
		cargarImagen("play");
		mediaPlayer = MediaPlayer.create(this, getResources().getIdentifier(preguntaActual.getSource(), "raw", getPackageName()));
		mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
			@Override
			public void onCompletion(MediaPlayer mp) {
				imagen.setImageResource(R.drawable.play);
			}
		});
	}

	private void cargarImagen(String source) {
		imagen.setVisibility(View.VISIBLE);
		imagen.setImageResource(getResources().getIdentifier(source, "drawable", getPackageName()));
	}

	public void ponerAudio(View v) {
		if (mediaPlayer != null) {
			if (!mediaPlayer.isPlaying()) {
				imagen.setImageResource(R.drawable.pause);
				mediaPlayer.start();
			} else {
				imagen.setImageResource(R.drawable.play);
				mediaPlayer.pause();
			}
		}
	}

	private void quitarAudio() {
		if (mediaPlayer != null) {
			imagen.setImageResource(R.drawable.play);
			mediaPlayer.stop();
			mediaPlayer = null;
		}
	}

	public void botonPulsado(View v) {
		final Button button = (Button) findViewById(v.getId());
		habilitarBotones(false);
		quitarAudio();
		final boolean correcto = comprobarRespuesta(button.getText().toString());
		if (correcto) {
			contador.acertada(preguntaActual.getCategoria());
			button.setBackgroundResource(R.drawable.button_green);
			sonidoAcertado.start();
		} else {
			contador.fallada(preguntaActual.getCategoria());
			button.setBackgroundResource(R.drawable.button_red);
			sonidoFallado.start();
		}
		button.setTextColor(Color.WHITE);
		final Context context = this;

		new AsyncTask<Void, Void, Void>() {
			@Override
			protected void onPreExecute() {
				if (correcto) {
					Toast.makeText(context, "Muy Bien! Has acertado!", Toast.LENGTH_SHORT).show();
				} else {
					Toast.makeText(context, "Has fallado. Otra vez será!", Toast.LENGTH_SHORT).show();
				}
			}

			@Override
			protected void onPostExecute(Void aVoid) {
				button.setBackgroundResource(R.drawable.button_white);
				button.setTextColor(Color.BLACK);
				hacerPregunta();
			}

			@Override
			protected Void doInBackground(Void... params) {
				try {
					Thread.sleep(2000);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
				return null;
			}
		}.execute(new Void[]{});
	}

}
