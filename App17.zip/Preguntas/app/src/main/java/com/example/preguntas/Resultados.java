package com.example.preguntas;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.TreeMap;


public class Resultados extends Activity {

	private Contador contador;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_resultados);
		contador = Contador.getInstance();
		mostrarResultados();
	}

	private void mostrarResultados() {
		TreeMap<Categoria, Integer> acertadas = contador.getAcertadasPorCategoria();
		TreeMap<Categoria, Integer> falladas = contador.getFalladasPorCategoria();

		Integer n_acertadas, n_falladas, n_total;
		for (Categoria categoria : Categoria.values()) {
			n_acertadas = acertadas.get(categoria);
			n_falladas = falladas.get(categoria);
			n_total = n_acertadas + n_falladas;

			cambiarValorTextView("acertadas_" + categoria.toString(), n_acertadas.toString());
			cambiarValorTextView("falladas_" + categoria.toString(), n_falladas.toString());
			cambiarValorTextView("total_" + categoria.toString(), n_total.toString());
		}
	}

	private void cambiarValorTextView(String id_str, String valor) {
		int id = getResources().getIdentifier(id_str, "id", getPackageName());
		TextView textView = (TextView) findViewById(id);
		textView.setText(valor);
	}
}
