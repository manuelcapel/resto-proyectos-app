package com.example.preguntas;

public enum TipoPregunta {
	NORMAL,
	AUDIO,
	IMAGEN
}
