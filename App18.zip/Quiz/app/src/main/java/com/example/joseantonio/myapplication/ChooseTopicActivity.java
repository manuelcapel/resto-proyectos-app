package com.example.joseantonio.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

/**
 * Created by Jose Antonio on 14/05/2015.
 */
public class ChooseTopicActivity extends ActionBarActivity {

    private String series="Series";
    private String peliculas="Peliculas";
    private String videojuegos="Videojuegos";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choosetopic);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_other_games, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void topicSeries(View view) {
    // Do something in response to button
        Intent intent = new Intent(this, QuestionsActivity.class);
        intent.putExtra("Tema",series);
       startActivity(intent);
    }

    public void topicVideogames(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, QuestionsActivity.class);
        intent.putExtra("Tema",videojuegos);
        startActivity(intent);
    }

    public void topicFilm(View view) {
        // Do something in response to button
        Intent intent = new Intent(this, QuestionsActivity.class);
        intent.putExtra("Tema",peliculas);
        startActivity(intent);
    }
}





