package com.example.joseantonio.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class QuestionsActivity extends ActionBarActivity {

    private QuestionsDataSource dataSource;
    private ImageView pregimg;
    private Button que1;
    private ImageView ique1;
    private Button que2;
    private ImageView ique2;
    private Button que3;
    private ImageView ique3;
    private Button que4;
    private ImageView ique4;
    private TextView preg;
    private ImageButton boaudio;
    private int correctas =0;
    private int falladas=0;
    private int soundr;

    MediaPlayer audio1;
    // Indicador de pregunta actual
    private int questionNum = -1;
    // Indicador de pregunta constestadas
    private int questionConst = 20;
    private String Tema;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preguntas);
        preg = (TextView) findViewById(R.id.pregunta);
        pregimg = (ImageView) findViewById(R.id.imgpreg);
        boaudio = (ImageButton) findViewById(R.id.boaudio);
        que1 = (Button) findViewById(R.id.question1);
        ique1 = (ImageView) findViewById(R.id.ique1);
        que2 = (Button) findViewById(R.id.question2);
        ique2 = (ImageView) findViewById(R.id.ique2);
        que3 = (Button) findViewById(R.id.question3);
        ique3 = (ImageView) findViewById(R.id.ique3);
        que4 = (Button) findViewById(R.id.question4);
        ique4 = (ImageView) findViewById(R.id.ique4);
        dataSource = new QuestionsDataSource(this);
      String tema=getIntent().getStringExtra("Tema");
        Tema=tema;
        showNextQuestion();



    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_preguntas, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void checkAnswer1 (View view){
        Cursor c = dataSource.getAllQuotes();

        int i = 0; //Numero de fila actual
        while(c.moveToNext()){
            // Cuando la fila actual no se corresponda
            // con la pregunta actual saltamos a la siguiente fila
            if (i != questionNum) {
                i++;
                continue;
            }
            String temabd = c.getString(13);//columna 1 tipo pregunta
            if(!Tema.equals(temabd)){
                continue;
            }

            String check = c.getString(5); //Columna 3 (check respuesta1)
            if (check.equals("true")){
                Log.d("Check respuesta 1 a pregunta " + i, "verdadera");
                mensaje("Respuesta correcta");
                audio1 =  MediaPlayer.create(this, R.raw.acierto);
                // audio1.setLooping(true);
                audio1.start();
                correctas++;
            } else {
                Log.d("Check respuesta 1 a pregunta" + i, "falsa");
                wrongquestion("Fallo la pregunta que desea hacer continuar o empezar de nuevo ?");
                audio1 =  MediaPlayer.create(this, R.raw.fallo);
                // audio1.setLooping(true);
                audio1.start();
                falladas++;
            }
            break;
        }

        showNextQuestion();

    }


    public void checkAnswer2 (View view){
        Cursor c = dataSource.getAllQuotes();

        int i = 0; //Numero de fila actual
        while(c.moveToNext()){
            // Cuando la fila actual no se corresponda
            // con la pregunta actual saltamos a la siguiente fila
            if (i != questionNum) {
                i++;
                continue;
            }
            String temabd = c.getString(13);//columna 1 tipo pregunta
            if(!Tema.equals(temabd)){
                continue;
            }

            String check = c.getString(7); //Columna 3 (check respuesta1)
            if (check.equals("true")){
                Log.d("Check respuesta 2 a pregunta " + i, "verdadera");
                mensaje("Respuesta correcta");
                audio1 =  MediaPlayer.create(this, R.raw.acierto);
               // audio1.setLooping(true);
                audio1.start();

                correctas++;
            } else {
                Log.d("Check respuesta 2 a pregunta" + i, "falsa");
                wrongquestion("Fallo la pregunta que desea hacer continuar o empezar de nuevo ?");
                audio1 =  MediaPlayer.create(this, R.raw.fallo);
                // audio1.setLooping(true);
                audio1.start();

                falladas++;
            }
            break;
        }

        showNextQuestion();

    }

    public void checkAnswer3 (View view){
        Cursor c = dataSource.getAllQuotes();

        int i = 0; //Numero de fila actual
        while(c.moveToNext()){
            // Cuando la fila actual no se corresponda
            // con la pregunta actual saltamos a la siguiente fila
            if (i != questionNum) {
                i++;
                continue;
            }
            String temabd = c.getString(13);//columna 1 tipo pregunta
            if(!Tema.equals(temabd)){
                continue;
            }

            String check = c.getString(9); //Columna 7 (check respuesta3)
            if (check.equals("true")){
                Log.d("Check respuesta 1 a pregunta " + i, "verdadera");
                mensaje("Respuesta correcta");
                audio1 =  MediaPlayer.create(this, R.raw.acierto);
                // audio1.setLooping(true);
                audio1.start();

                correctas++;
            } else {
                Log.d("Check respuesta 1 a pregunta" + i, "falsa");
                wrongquestion("Fallo la pregunta que desea hacer continuar o empezar de nuevo ?");
                audio1 =  MediaPlayer.create(this, R.raw.fallo);
                // audio1.setLooping(true);
                audio1.start();

                falladas++;
            }
            break;
        }

        showNextQuestion();

    }

    public void checkAnswer4 (View view){
        Cursor c = dataSource.getAllQuotes();

        int i = 0; //Numero de fila actual
        while(c.moveToNext()){
            // Cuando la fila actual no se corresponda
            // con la pregunta actual saltamos a la siguiente fila
            if (i != questionNum) {
                i++;
                continue;
            }
            String temabd = c.getString(13);//columna 1 tipo pregunta
            if(!Tema.equals(temabd)){
                continue;
            }

            String check = c.getString(11); //Columna 9 (check respuesta4)
            if (check.equals("true")){
                Log.d("Check respuesta 4 a pregunta " + i, "verdadera");
                mensaje("Respuesta correcta");
                audio1 =  MediaPlayer.create(this, R.raw.acierto);
                // audio1.setLooping(true);
                audio1.start();

                correctas++;

            } else {
                Log.d("Check respuesta 4 a pregunta" + i, "falsa");
                wrongquestion("Fallo la pregunta que desea hacer continuar o empezar de nuevo ?");
                audio1 =  MediaPlayer.create(this, R.raw.fallo);
                // audio1.setLooping(true);
                audio1.start();

                falladas++;
            }
            break;
        }

        showNextQuestion();

    }




    public void showNextQuestion() {


        Cursor c = dataSource.getAllQuotes();

        questionNum++;

        int i = 0; //Numero de fila actual
        while(c.moveToNext()) {
            // Cuando la fila actual no se corresponda
            // con la pregunta actual saltamos a la siguiente fila
            if (i != questionNum){
                i++;
                continue;
            }
            String questiontype = c.getString(1);//columna 1 tipo pregunta
            String temabd = c.getString(13);//columna 1 tipo pregunta
            if(!Tema.equals(temabd)){
                continue;
            }
            if(questiontype.equals("0")){
                String question = c.getString(3); //Columna 1 (Pregunta)
                preg.setText(question);
                preg.setVisibility(View.VISIBLE);
                pregimg.setVisibility(View.GONE);
                boaudio.setVisibility(View.GONE);
                Log.d("Asignada pregunta", question);
                }
                else if(questiontype.equals("2")){
                String sound = c.getString(12); //columna 2 imagen

                String question = c.getString(3); //Columna 1 (Pregunta)
                preg.setText(question);
                int iresource = this.getResources().getIdentifier(sound, "raw", this.getPackageName());
                soundr=iresource;
                pregimg.setImageResource(iresource);
                preg.setVisibility(View.VISIBLE);
                pregimg.setVisibility(View.GONE);
                boaudio.setVisibility(View.VISIBLE);
                Log.d("asigno audiooo",sound);
            }
                else{
                String question = c.getString(3); //Columna 1 (Pregunta)
                preg.setText(question);
                String image = c.getString(2); //columna 2 imagen
                int iresource = this.getResources().getIdentifier(image, "drawable", this.getPackageName());
                pregimg.setImageResource(iresource);
                preg.setVisibility(View.VISIBLE);
                pregimg.setVisibility(View.VISIBLE);
                boaudio.setVisibility(View.GONE);
                Log.d("asigno imagen",image);
            }


            if(questiontype.equals("0")||questiontype.equals("2")){
            String answer1 = c.getString(4); //Columna 2 (Respuesta 1)
            que1.setText(answer1);
            que1.setVisibility(View.VISIBLE);
            ique1.setVisibility(View.GONE);
            Log.d("Asignada respuesta 1", answer1);
            Log.e("dsddsd",Tema);

            }else{
                String image = c.getString(4); //columna 2 imagen
                int iresource = this.getResources().getIdentifier(image, "drawable", this.getPackageName());
                ique1.setImageResource(iresource);
                que1.setVisibility(View.GONE);
                ique1.setVisibility(View.VISIBLE);
                Log.d("asigno imagen",image);
            }

            if(questiontype.equals("0")||questiontype.equals("2")){
            String answer2 = c.getString(6); //Columna 3 (Respuesta 2)
            que2.setText(answer2);
            que2.setVisibility(View.VISIBLE);
            ique2.setVisibility(View.GONE);
            Log.d("Asignada respuesta 2", answer2);
            }else{
                String image = c.getString(6); //columna 2 imagen
                int iresource = this.getResources().getIdentifier(image, "drawable", this.getPackageName());
                ique2.setImageResource(iresource);
                que2.setVisibility(View.GONE);
                ique2.setVisibility(View.VISIBLE);
                Log.d("asigno imagen",image);
            }

            if(questiontype.equals("0")||questiontype.equals("2")){
            String answer3 = c.getString(8); //Columna 6 (Respuesta 3)
            que3.setText(answer3);
            que3.setVisibility(View.VISIBLE);
            ique3.setVisibility(View.GONE);

            Log.d("Asignada respuesta 3", answer3);
            }else{
                String image = c.getString(8); //columna 2 imagen
                int iresource = this.getResources().getIdentifier(image, "drawable", this.getPackageName());
                ique3.setImageResource(iresource);
                que3.setVisibility(View.GONE);
                ique3.setVisibility(View.VISIBLE);
                Log.d("asigno imagen",image);
            }

            if(questiontype.equals("0")||questiontype.equals("2")){
            String answer4 = c.getString(10); //Columna 8 (Respuesta 4)
            que4.setText(answer4);
            que4.setVisibility(View.VISIBLE);
            ique4.setVisibility(View.GONE);
            Log.d("Asignada respuesta 4", answer4);
            }else{
                String image = c.getString(10); //columna 2 imagen
                int iresource = this.getResources().getIdentifier(image, "drawable", this.getPackageName());
                ique4.setImageResource(iresource);
                que4.setVisibility(View.GONE);
                ique4.setVisibility(View.VISIBLE);
                Log.d("asigno imagen",image);
            }

            break;

        }
        if(i==questionConst){
            finalgame();
        }


    }

    public void mensaje(String cadena){
        Toast.makeText(this, cadena, Toast.LENGTH_SHORT).show();
    }

    public void wrongquestion(final String cadena){
        //se prepara la alerta creando nueva instancia
        AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
        //seleccionamos la cadena a mostrar
        alertbox.setMessage(cadena);
        //elegimos un positivo SI y creamos un Listener
        alertbox.setPositiveButton("Continuar", new DialogInterface.OnClickListener() {
            //Funcion llamada cuando se pulsa el boton Si
            public void onClick(DialogInterface arg0, int arg1) {
                mensaje("Asi se hace animo !!!");
            }
        });

        //elegimos un positivo NO y creamos un Listener
        alertbox.setNegativeButton("Reiniciar", new DialogInterface.OnClickListener() {
            //Funcion llamada cuando se pulsa el boton No
            public void onClick(DialogInterface arg0, int arg1) {
                //mensaje("Pulsado el botón NO");


                startGame();

            }
        });

        //mostramos el alertbox
        alertbox.show();
    }
    public void finalgame(){
        String cadena="Felicidades has acabado el juego, ahora tienes dos opciones :";
        audio1 =  MediaPlayer.create(this, R.raw.acabado);
        audio1.start();
        //se prepara la alerta creando nueva instancia
        AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
        //seleccionamos la cadena a mostrar
        alertbox.setMessage(cadena);
        //elegimos un positivo SI y creamos un Listener
        alertbox.setPositiveButton("Reintentar", new DialogInterface.OnClickListener() {
            //Funcion llamada cuando se pulsa el boton Si
            public void onClick(DialogInterface arg0, int arg1) {
                mensaje("intento de nuevo");
                startGame();

            }
        });

        //elegimos un positivo NO y creamos un Listener
        alertbox.setNegativeButton("Resultado", new DialogInterface.OnClickListener() {
            //Funcion llamada cuando se pulsa el boton No
            public void onClick(DialogInterface arg0, int arg1) {
             //   mensaje("resultados");
              viewResult();
                // enviar dos valores para que los pinte la grafica que esta en ver resultado de la partida
            }
        });

        //mostramos el alertbox
        alertbox.show();
    }
    public void startaudio(View view){
        audio1 =  MediaPlayer.create(this, soundr);
        audio1.start();
    }
    public void viewResult() {
        // Do something in response to button
        Intent intent = new Intent(this, ViewResultActivity.class);
        intent.putExtra("acertadas",correctas);
        intent.putExtra("falladas",falladas);
        startActivity(intent);
    }
    public void startGame() {

        Intent intent = new Intent(this, ChooseTopicActivity.class);
        startActivity(intent);
    }
}
