package com.example.joseantonio.myapplication;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.BaseColumns;
import android.util.Log;

import java.io.IOException;
import java.sql.SQLException;

/**
 * Created by Jose Antonio on 23/04/2015.
 */
public class QuestionsDataSource {

    //Metainformación de la base de datos
    public static final String QUOTES_TABLE_NAME = "Questions";
    public static final String STRING_TYPE = "text";
    public static final String INT_TYPE = "integer";

    //Campos de la tabla Questions
    public static class ColumnQuotes{
        public static final String ID_QUOTES = BaseColumns._ID;
        public static final String QUESTIONS_TYPE= "tipo_pregunta";
        public static final String IMAGE="imagen";
        public static final String QUESTION = "pregunta";
        public static final String ANSWER1 = "respuesta1";
        public static final String CORRECT1 = "correcta1";
        public static final String ANSWER2 = "respuesta2";
        public static final String CORRECT2 = "correcta2";
        public static final String ANSWER3 = "respuesta3";
        public static final String CORRECT3 = "correcta3";
        public static final String ANSWER4 = "respuesta4";
        public static final String CORRECT4 = "correcta4";
        public static final String SOUND = "sonido";
        public static final String TOPIC= "tema";
    }

    public static final String DROP_QUOTES_SCRIPT = "DROP TABLE IF EXISTS Questions";

    //Script de Creación de la tabla Quotes
    public static final String CREATE_QUOTES_SCRIPT =
            "create table "+QUOTES_TABLE_NAME+"(" +
                    ColumnQuotes.ID_QUOTES+" "+INT_TYPE+" primary key autoincrement," +
                    ColumnQuotes.QUESTIONS_TYPE+" "+INT_TYPE+","+
                    ColumnQuotes.IMAGE+" "+STRING_TYPE+" not null,"+
                    ColumnQuotes.QUESTION +" "+STRING_TYPE+" not null," +
                    ColumnQuotes.ANSWER1 +" "+STRING_TYPE+" not null," +
                    ColumnQuotes.CORRECT1 +" "+STRING_TYPE+" not null," +
                    ColumnQuotes.ANSWER2 +" "+STRING_TYPE+" not null," +
                    ColumnQuotes.CORRECT2 +" "+STRING_TYPE+" not null," +
                    ColumnQuotes.ANSWER3 +" "+STRING_TYPE+" not null," +
                    ColumnQuotes.CORRECT3 +" "+STRING_TYPE+" not null," +
                    ColumnQuotes.ANSWER4 +" "+STRING_TYPE+" not null," +
                    ColumnQuotes.CORRECT4 +" "+STRING_TYPE+" not null,"+
                    ColumnQuotes.SOUND +" "+STRING_TYPE+" not null,"+
                    ColumnQuotes.TOPIC +" "+STRING_TYPE+" not null)";

    public static final String INSERT_QUOTES_SCRIPT =
            "insert into "+QUOTES_TABLE_NAME+" values(" +
                    "null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Quien dijo esta frase : Tendrá todo el dinero del mundo, pero hay una cosa que nunca podrá comprar: un dinosaurio.\"," +
                    "\"Buda\"," +
                    "\"false\"," +
                    "\"Homer Simpsons\"," +
                    "\"true\"," +
                    "\"Peter Griffin\"," +
                    "\"false\"," +
                    "\"Reverendo Lovejoy\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Series\")," +
                    "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que animal es simba ?\"," +
                    "\"Cerdo\"," +
                    "\"false\"," +
                    "\"Perro\"," +
                    "\"false\"," +
                    "\"Zorro\"," +
                    "\"false\"," +
                    "\"Leon\"," +
                    "\"true\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
					 "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"A que pelicula pertenece esta Banda Sonora ?\"," +
                    "\"Indiana Jones\"," +
                    "\"true\"," +
                    "\"Cazafantamas\"," +
                    "\"false\"," +
                    "\"Futurama\"," +
                    "\"false\"," +
                    "\"Erase una vez\"," +
                    "\"false\"," +
                    "\"pe1\"," +
                    "\"Peliculas\")," +
					 "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"Quien grita asi ?\"," +
                    "\"Dinosaurio\"," +
                    "\"false\"," +
                    "\"bart simpson\"," +
                    "\"false\"," +
                    "\"bender\"," +
                    "\"false\"," +
                    "\"Godzilla\"," +
                    "\"true\"," +
                    "\"pe4\"," +
                    "\"Peliculas\")," +
					 "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"A que pelicula pertenece esta Banda Sonora ?\"," +
                    "\"Indiana Jones\"," +
                    "\"false\"," +
                    "\"Cazafantamas\"," +
                    "\"true\"," +
                    "\"Futurama\"," +
                    "\"false\"," +
                    "\"Erase una vez\"," +
                    "\"false\"," +
                    "\"p2\"," +
                    "\"Peliculas\")," +
                    "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"Que personaje hace este sonido ?\"," +
                    "\"Richard Castle\"," +
                    "\"false\"," +
                    "\"Monstruo de las Galletas\"," +
                    "\"true\"," +
                    "\"Pluto\"," +
                    "\"false\"," +
                    "\"Chip\"," +
                    "\"false\"," +
                    "\"se3\"," +
                    "\"Series\")," +
                    "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"Que personaje dice esta frase ?\"," +
                    "\"Peter Griffin\"," +
                    "\"true\"," +
                    "\"Luke Dunphy\"," +
                    "\"false\"," +
                    "\"Barney Stinson\"," +
                    "\"false\"," +
                    "\"Sheldon Cooper\"," +
                    "\"false\"," +
                    "\"se4\"," +
                    "\"Series\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Quien dirigio Star Wars ?\"," +
                    "\"George clooney\"," +
                    "\"false\"," +
                    "\"George Harrison\"," +
                    "\"false\"," +
                    "\"George de la jungla\"," +
                    "\"false\"," +
                    "\"George Lucas\"," +
                    "\"true\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que es Hercules ?\"," +
                    "\"Semidios\"," +
                    "\"true\"," +
                    "\"Dios\"," +
                    "\"false\"," +
                    "\"Humano\"," +
                    "\"false\"," +
                    "\"Indefinido\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
                    "(null," +
                    "\"1\"," +
                    "\"pregunta\"," +
                    "\"Que imagen encaja ?\"," +
                    "\"respuesta1\"," +
                    "\"false\"," +
                    "\"respuesta2\"," +
                    "\"false\"," +
                    "\"repuesta3\"," +
                    "\"true\"," +
                    "\"respuesta4\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Series\")," +
					 "(null," +
                    "\"1\"," +
                    "\"pe1\"," +
                    "\"Que actriz encarnaba a este personaje ?\"," +
                    "\"pe3r\"," +
                    "\"false\"," +
                    "\"pe2r\"," +
                    "\"false\"," +
                    "\"pe1r\"," +
                    "\"true\"," +
                    "\"pe4r\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que invento Dock brown ?\"," +
                    "\"Maquina del tiempo\"," +
                    "\"true\"," +
                    "\"cafetera\"," +
                    "\"false\"," +
                    "\"Horno\"," +
                    "\"false\"," +
                    "\"Game boy\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"En que epoca esta ambientada en Regreso al futuro I ?\"," +
                    "\"los 80s\"," +
                    "\"true\"," +
                    "\"los 90s\"," +
                    "\"false\"," +
                    "\"los 2000s\"," +
                    "\"false\"," +
                    "\"los 30s\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Quien ayuda a aladdin?\"," +
                    "\"Genio\"," +
                    "\"true\"," +
                    "\"Dios\"," +
                    "\"false\"," +
                    "\"Humano\"," +
                    "\"false\"," +
                    "\"Indefinido\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que objeto caracteriza al conejo de alicia en el pais ?\"," +
                    "\"Reloj\"," +
                    "\"true\"," +
                    "\"Flauta\"," +
                    "\"false\"," +
                    "\"Ordenador\"," +
                    "\"false\"," +
                    "\"Botella\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Quien se come una manzana y cae en sueño eterno ?\"," +
                    "\"Pocahontas\"," +
                    "\"false\"," +
                    "\"Simba\"," +
                    "\"false\"," +
                    "\"Blanca nieves\"," +
                    "\"false\"," +
                    "\"Aladdin\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que tienen de especial los juguetes de toy story ?\"," +
                    "\"Viven\"," +
                    "\"true\"," +
                    "\"nada\"," +
                    "\"false\"," +
                    "\"son caros\"," +
                    "\"false\"," +
                    "\"son feos\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que cambia ariel por tener piernas?\"," +
                    "\"nada\"," +
                    "\"false\"," +
                    "\"la voz\"," +
                    "\"true\"," +
                    "\"Vende al cangrejo\"," +
                    "\"false\"," +
                    "\"Se come al pez\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Peliculas\")," +
					
                    "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"A que pelicula corresponde este sonido ?\"," +
                    "\"Regreso al futuro I\"," +
                    "\"false\"," +
                    "\"Jurasic Park\"," +
                    "\"false\"," +
                    "\"La milla Verde\"," +
                    "\"false\"," +
                    "\"Star Wars\"," +
                    "\"true\"," +
                    "\"chee\"," +
                    "\"Peliculas\")," +
                    "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que personaje decia esta frase : ¿ he sido yo ?\"," +
                    "\"Steve urkel\"," +
                    "\"true\"," +
                    "\"Homer simpson\"," +
                    "\"false\"," +
                    "\"Richard Castle\"," +
                    "\"false\"," +
                    "\"Sheldon Cooper\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Series\")," +
                    "(null," +
                    "\"1\"," +
                    "\"pese1\"," +
                    "\"Que imagen encaja ?\"," +
                    "\"se4\"," +
                    "\"false\"," +
                    "\"se2\"," +
                    "\"false\"," +
                    "\"se1\"," +
                    "\"true\"," +
                    "\"se3\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Series\")," +
                    "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"Que personaje dice esta frase ?\"," +
                    "\"Richard Castle\"," +
                    "\"false\"," +
                    "\"Luke Dunphy\"," +
                    "\"false\"," +
                    "\"Barney Stinson\"," +
                    "\"false\"," +
                    "\"Sheldon Cooper\"," +
                    "\"true\"," +
                    "\"se2\"," +
                    "\"Series\")," +
                    "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"Que pasaba cuando sonaba este sonido ?\"," +
                    "\"Obtenias una vida\"," +
                    "\"false\"," +
                    "\"Pasabas de nivel\"," +
                    "\"false\"," +
                    "\"Te comias a alguien\"," +
                    "\"false\"," +
                    "\"Morias\"," +
                    "\"true\"," +
                    "\"vi2\"," +
                    "\"Videojuegos\")," +
                    "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"Que pasaba cuando sonaba este sonido ?\"," +
                    "\"Obtenias una vida\"," +
                    "\"true\"," +
                    "\"Pasabas de nivel\"," +
                    "\"false\"," +
                    "\"Te comias a alguien\"," +
                    "\"false\"," +
                    "\"Morias\"," +
                    "\"false\"," +
                    "\"vi1\"," +
                    "\"Videojuegos\")," +
                    "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"Que pasaba cuando sonaba este sonido ?\"," +
                    "\"Obtenias una vida\"," +
                    "\"false\"," +
                    "\"Pasabas de nivel\"," +
                    "\"false\"," +
                    "\"Te comias a alguien\"," +
                    "\"false\"," +
                    "\"te curaban\"," +
                    "\"true\"," +
                    "\"vi3\"," +
                    "\"Videojuegos\")," +
                    "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que personaje decia esta frase : ¿ Tu no mami ?\"," +
                    "\"Earl sinclair\"," +
                    "\"false\"," +
                    "\"Peque sinclair\"," +
                    "\"true\"," +
                    "\"Lois griffin\"," +
                    "\"false\"," +
                    "\"Rick Grimes\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Series\")," +
					 "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Quien dice pika pika ?\"," +
                    "\"Pichu\"," +
                    "\"false\"," +
                    "\"Pikachu\"," +
                    "\"true\"," +
                    "\"Mario\"," +
                    "\"false\"," +
                    "\"Peach\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					 "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que tenias que hacer en el puzzle bobble ?\"," +
                    "\"Limpiar el mapa\"," +
                    "\"false\"," +
                    "\"Hacer combinaciones con las bolas\"," +
                    "\"true\"," +
                    "\"Conseguir monedas\"," +
                    "\"false\"," +
                    "\"Matar gente\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					 "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"De que nacionalidad era el que invento el tetris ?\"," +
                    "\"Aleman\"," +
                    "\"false\"," +
                    "\"Ruso\"," +
                    "\"true\"," +
                    "\"Español\"," +
                    "\"false\"," +
                    "\"Frances\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					 "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que compañia enterro un videojuego ?\"," +
                    "\"EA\"," +
                    "\"false\"," +
                    "\"Atari\"," +
                    "\"true\"," +
                    "\"Thq\"," +
                    "\"false\"," +
                    "\"Activision\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					 "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"A quien intenta rescatar mario?\"," +
                    "\"Su madre\"," +
                    "\"false\"," +
                    "\"Princesa Peach\"," +
                    "\"true\"," +
                    "\"Princesa Daisy\"," +
                    "\"false\"," +
                    "\"A su mascota\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que hay que completar en pokemon ?\"," +
                    "\"Pokedex\"," +
                    "\"true\"," +
                    "\"Medallas\"," +
                    "\"false\"," +
                    "\"bayas\"," +
                    "\"false\"," +
                    "\"objetos raros\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que tienes que conseguir en Sonic ?\"," +
                    "\"Anillos\"," +
                    "\"false\"," +
                    "\"Mazana\"," +
                    "\"true\"," +
                    "\"Peras\"," +
                    "\"false\"," +
                    "\"Botellas\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"En que juego tienes que encajar piezas ?\"," +
                    "\"Tetris\"," +
                    "\"true\"," +
                    "\"Pokemon\"," +
                    "\"false\"," +
                    "\"Mario\"," +
                    "\"false\"," +
                    "\"Metal gear solid\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que tienes que hacer en animal Crossing ?\"," +
                    "\"Ser alcalde\"," +
                    "\"true\"," +
                    "\"Matar gente\"," +
                    "\"false\"," +
                    "\"Comer gente\"," +
                    "\"false\"," +
                    "\"Estafar a la gente\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que le tiraba donkey kong a mario ?\"," +
                    "\"barriles\"," +
                    "\"true\"," +
                    "\"platanos\"," +
                    "\"false\"," +
                    "\"fresas\"," +
                    "\"false\"," +
                    "\"manzanas\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que tienes que conseguir en crash bandicoot ?\"," +
                    "\"Manzanas\"," +
                    "\"true\"," +
                    "\"Anillos\"," +
                    "\"false\"," +
                    "\"Monedas\"," +
                    "\"false\"," +
                    "\"Joyas\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Videojuegos\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que paso en the walking dead ?\"," +
                    "\"Apocalipsis Zombie\"," +
                    "\"true\"," +
                    "\"Nada\"," +
                    "\"false\"," +
                    "\"Peleas de sumos\"," +
                    "\"false\"," +
                    "\"Cae un meteorito\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Series\")," +
					"(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que animal es isidoro (dibujos animados) ?\"," +
                    "\"Perro\"," +
                    "\"false\"," +
                    "\"Pez\"," +
                    "\"false\"," +
                    "\"Gato\"," +
                    "\"true\"," +
                    "\"Indefinido\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Series\")," +
                    "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"En que trabaja Phil dunphy ?\"," +
                    "\"Agente inmobilario\"," +
                    "\"true\"," +
                    "\"Informatico\"," +
                    "\"false\"," +
                    "\"Profesor\"," +
                    "\"false\"," +
                    "\"Taxista\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Series\")," +
                    "(null," +
                    "\"2\"," +
                    "\"\"," +
                    "\"Que personaje dice esta frase ?\"," +
                    "\"Ramon Garcia\"," +
                    "\"false\"," +
                    "\"Alan Cid\"," +
                    "\"false\"," +
                    "\"Barney Stinson\"," +
                    "\"true\"," +
                    "\"Alf\"," +
                    "\"false\"," +
                    "\"barney\"," +
                    "\"Series\")," +
                    "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"A que planeta pertenece alf ?\"," +
                    "\"la tierra\"," +
                    "\"false\"," +
                    "\"Pluton\"," +
                    "\"false\"," +
                    "\"Melmac\"," +
                    "\"true\"," +
                    "\"Andromeda\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Series\")," +
                    "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que le gusta comer a alf ?\"," +
                    "\"Galletas\"," +
                    "\"false\"," +
                    "\"Perros\"," +
                    "\"false\"," +
                    "\"Gatos\"," +
                    "\"true\"," +
                    "\"Nocilla\"," +
                    "\"false\"," +
                    "\"\"," +
                    "\"Series\")," +
                    "(null," +
                    "\"0\"," +
                    "\"\"," +
                    "\"Que busca Ted mosby ?\"," +
                    "\"Odio\"," +
                    "\"false\"," +
                    "\"Venganza\"," +
                    "\"false\"," +
                    "\"Dinero\"," +
                    "\"false\"," +
                    "\"Amor\"," +
                    "\"true\"," +
                    "\"\"," +
                    "\"Series\")";

    private QuotesReaderDbHelper openHelper;
    private SQLiteDatabase database;



    public QuestionsDataSource(Context context) {
        //Creando una instancia hacia la base de datos
       openHelper = new QuotesReaderDbHelper(context);
        database = openHelper.getWritableDatabase();

      //  Questionsdb myDbHelper = new Questionsdb(context);


      //  try {

      //      myDbHelper.createDataBase();

     //   } catch (IOException ioe) {

          //  throw new Error("Unable to create database");

      //  }

      //  try {

        //    myDbHelper.openDataBase();

       // }catch(SQLException sqle){

          //  throw sqle;
        //    Log.e("Error sql",sqle.getMessage());

       // }

       // database = openHelper.getReadableDatabase();
    }

    public Cursor getAllQuotes(){
        //Seleccionamos todas las filas de la tabla Quotes
        return database.rawQuery(
                "select * from " + QUOTES_TABLE_NAME, null);
    }


}
