package com.example.joseantonio.myapplication;

import android.graphics.Color;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.github.mikephil.charting.utils.Highlight;
import com.github.mikephil.charting.utils.PercentFormatter;

import java.util.ArrayList;


public class ViewResultActivity extends ActionBarActivity {


    private RelativeLayout fondo;
    private PieChart nchart;


    private float[] yData = {60,40};
    private String[] xData = {"Falladas","Acertadas"};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_result);
        fondo =(RelativeLayout) findViewById(R.id.fondo);
        nchart = new PieChart(this);
        fondo.addView(nchart);
        fondo.setBackgroundColor(Color.parseColor("#FFE0B0"));

        //configurar la pie
        nchart.setUsePercentValues(true);
        nchart.setDescription("Preguntas Falladas y Acertadas en la ultima partida");

        //enable hole and configure

        nchart.setDrawHoleEnabled(true);
        nchart.setHoleColorTransparent(true);
        nchart.setHoleRadius(7);
        nchart.setTransparentCircleRadius(10);

        //enable rotation of the chart by touck

        nchart.setRotationAngle(0);
        nchart.setRotationEnabled(true);

        nchart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, int i, Highlight highlight) {
                //display msh value selected
                if(e==null)
                    return;

                Toast.makeText(ViewResultActivity.this,xData[e.getXIndex()]+" = " + e.getVal() + "%",Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected() {

            }
        });

        //add data
        addData();


        Legend l = nchart.getLegend();
        l.setPosition(Legend.LegendPosition.RIGHT_OF_CHART);
        l.setXEntrySpace(7);
        l.setYEntrySpace(5);

        int Acertadas=getIntent().getIntExtra("acertadas",-1);
        int Falladas=getIntent().getIntExtra("falladas",-1);
        yData[0] = Falladas;
        yData[1] = Acertadas;
    }

    private void addData(){

        ArrayList<Entry> yVals1 = new ArrayList<Entry>();

        for (int i=0;i < yData.length;i++)
            yVals1.add(new Entry(yData[i],i));

        ArrayList<String> xVals = new ArrayList<String>();

        for (int i=0;i < xData.length;i++)
            xVals.add(xData[i]);

        PieDataSet dataSet= new PieDataSet(yVals1,"");
        dataSet.setSliceSpace(3);
        dataSet.setSelectionShift(5);


        ArrayList<Integer> colors = new ArrayList<Integer>();

        for (int c : ColorTemplate.JOYFUL_COLORS)
            colors.add(c);

        for (int c : ColorTemplate.PASTEL_COLORS)
            colors.add(c);

        colors.add(ColorTemplate.getHoloBlue());
        dataSet.setColors(colors);

        PieData data = new PieData(xVals,dataSet);
        data.setValueFormatter(new PercentFormatter());
        data.setValueTextSize(11f);
        data.setValueTextColor(Color.BLACK);

        nchart.setData(data);

        nchart.highlightValues(null);

        nchart.invalidate();



    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_view_result, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
