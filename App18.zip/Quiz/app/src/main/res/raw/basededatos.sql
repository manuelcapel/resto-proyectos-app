BEGIN TRANSACTION;
CREATE TABLE "Questions" (
	`_ID`	INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
	`tipo_pregunta`	TEXT NOT NULL,
	`imagen`	TEXT NOT NULL,
	`pregunta`	TEXT NOT NULL,
	`respuesta1`	TEXT NOT NULL,
	`correcta1`	TEXT NOT NULL,
	`respuesta2`	TEXT NOT NULL,
	`correcta2`	TEXT NOT NULL,
	`respuesta3`	TEXT NOT NULL,
	`correcta3`	TEXT NOT NULL,
	`respuesta4`	TEXT NOT NULL,
	`correcta4`	TEXT NOT NULL,
	`sonido`	TEXT NOT NULL,
	`tema`	TEXT NOT NULL
);
INSERT INTO `Questions` VALUES (1,'0','','Quien dijo esta frase : Tendrá todo el dinero del mundo, pero hay una cosa que nunca podrá comprar: un dinosaurio.','Buda','false','Peter Griffin','false','Homer Simpson','true
','Gandih','false','','Series');
INSERT INTO `Questions` VALUES (2,'0','','Que animal es Simba ?','Zorro','false','leon','true','Perro','false','Pajaro','false','','Peliculas');
INSERT INTO `Questions` VALUES (3,'1','pregunta','Que imagen encaja ?','respuesta1','false
','respuesta2','false','respuesta3','true','respuesta4','false','','Series');
INSERT INTO `Questions` VALUES (4,'2','','A que pelicula corresponde este sonido ?','Starwars','true','La leyenda del zorro','false','Jurasic Park','false','Regreso al futuro I','false','chee','Peliculas');
COMMIT;
