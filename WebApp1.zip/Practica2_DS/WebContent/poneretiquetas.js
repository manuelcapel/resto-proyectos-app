/**
 * Funciones necesarias para poder añadir las "gotas" y etiquetas al mapa de google maps
 */

function mostrarDatosEtiquetas(){
	//var actividades = <%=actividades%>
	//<%String s = lugarRecurso.getMarcadoresHTML(); %>
	document.getElementById("demo").innerHTML = "No se como poner las etiquetas ";
}

function loadScript(){
	document.getElementById("demo").innerHTML = "Probando otras cosas ";
	var script = document.createElement("script");
	script.type = "text/javascript";
	script.src = "http://maps.googleapis.com/maps/api/js?key=&sensor=false&callback=initialize";
	document.body.appendChild(script);
}

function initialize() {
	var mapProp = {center:myCenter,
			zoom:8,
			mapTypeId:google.maps.MapTypeId.ROADMAP};

	var map=new google.maps.Map(document.getElementById("mapa"),mapProp);
	
	for (i = 0; i < 2; i++) { 
		var pos;
		if(i==0){
			pos=new google.maps.LatLng(36.997806, -3.891358);
		}else{
		    pos=new google.maps.LatLng(37.581431,-3.244359)
		}
		
		var marker=new google.maps.Marker({position:pos,});
		marker.setMap(map);
	}
}

function addMarker(id, latitude, longitude, title, map)
{
    latitude = latitude.replace(',', '.');
    longitude = longitude.replace(',', '.');
    var latLng = new google.maps.LatLng(parseFloat(latitude), parseFloat(longitude));

    var marker = new google.maps.Marker({
        position: latLng,
        title: title,
        map: map,
        draggable: false
    });

    google.maps.event.addListener(marker,'click',function() {
        onMarkerClicked(map, id);
    });

}

function onMarkerClicked(map, id) {
    window.location.href = 'DetailsMunicipio/'+id; //<----------------------------- CAMBIAR ------------------------------------
}
