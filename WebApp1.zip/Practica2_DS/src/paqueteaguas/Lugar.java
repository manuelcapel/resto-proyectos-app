package paqueteaguas;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.xml.bind.annotation.XmlRootElement;

/*
 * Clase para implementar los lugares. 
 * Estos se definen por un Nombre, unas coordenadas, un enlace 
 * y puede haber im�genes asociadas
 */
@XmlRootElement
@Entity
public class Lugar implements Serializable{
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE)
	private Integer LugarId;
	private String Nombre;
	private String latitud;
	private String longitud;
	private String url;
	private String imagenes;
	
	/*
	 * Constructores
	 */
	// Constructor por defecto
	public Lugar(){
		Nombre="";
		latitud="";
		longitud="";
		url="";
		imagenes="";
	}
	
	// Constructor por par�metros
	public Lugar(String nomb, String lat, String lon, String enlace, String imgn){
		Nombre=nomb;
		latitud=lat;
		longitud=lon;
		url=enlace;
		imagenes=imgn;
	}
	
	// Constructor de copia
	public Lugar(Lugar l){
		Nombre=l.Nombre;
		latitud=l.latitud;
		longitud=l.longitud;
		url=l.url;
		imagenes=l.imagenes;
	}
	
	/*--- Funciones get ---*/
	
	public Integer getId(){return LugarId;	}
	public String getNombre(){return Nombre;	}
	public String getLatitud(){return latitud;	}
	public String getLongitud(){return longitud;	}
	public String getURL(){return url;	}
	public String getImagen(){return imagenes;	}
	
	/*--- Funciones set ---*/
	
	public void setId(Integer id){LugarId = id;}
	public void setNombre(String nomb){Nombre = nomb;}
	public void setLatitud(String lat){latitud = lat;}
	public void setLongitud(String lon){longitud = lon;}
	public void setURL(String enlace){url = enlace;}
	public void setImagen(String imgn){imagenes = imgn;}
	
	
	/*---- M�todo toString para poder mostrar por pantalla ----*/
	@Override
	public String toString() {
		System.out.println("PROBANDO to string de Lugar---------------------- " + Nombre);
		
		String lugar = String.format(LugarId.toString() + " "+ Nombre + " " + "Situado en: " + latitud + "," + longitud 
				+" Sitio web: " +url+ "\n"+imagenes);
		System.out.println("PROBANDO to string de Lugar---------------------- " + lugar);
		
		return lugar;
	}
	
}
