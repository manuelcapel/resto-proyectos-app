package paqueteaguas;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;


public class LugarBD {
	// Atributos para la base de datos.
	private static EntityManagerFactory factoria;
	private static final String PERSISTENCE_UNIT_NAME = "persistencia";
	static{
		factoria = Persistence.createEntityManagerFactory(PERSISTENCE_UNIT_NAME);
	}
	
	/*
	 * Inserta un lugar a la base de datos.
	 * @param lugar : Lugar que se va a insertar.
	 */
	public static void insertar(Lugar lugar) {
		EntityManager em = factoria.createEntityManager();
		
		if(!existeLugar(lugar)){ // Si el lugar a insertar no est� ya en la BD
			// Comenzar una nueva transaccion local 
			em.getTransaction().begin();
			//de tal forma que pueda persistir como una nueva entidad
			em.persist(lugar);
			// Ahora hay que hacer "commit", lo que causara que la
			// entidad se almacene en la base de datos
			em.getTransaction().commit();
			// Ahora hay que cerrar (la conexi�n) el EntityManager
			em.close();
			System.out.println("Lugar insertado.");
		}
		else{
			System.out.println("El lugar ya estaba insertado.");
		}
	}
	
	/*
	 * Obtener un lugar concreto de la base de datos
	 * 
	 * @return Devuelve el lugar cuyo LugarId sea idLugar
	 * 		 	de no estar, devuelve null
	 */
	@SuppressWarnings("unchecked")
	public static Lugar getLugar(int idLugar){
		Lugar l;
		List<Lugar> listaLugares; 
		
		EntityManager em = factoria.createEntityManager();
		
		// Hacemos la consulta
		Query q = em.createQuery("SELECT u FROM Lugar u WHERE u.LugarId='" + idLugar + "'");
		// Anotamos el resultado.
		listaLugares = q.getResultList();
		if(listaLugares.size() != 0)
			l = listaLugares.get(0); //Nos quedamos con el primero
		else 
			return null;
		// Cerramos el gestor
		em.close();
		return l;
	}
	
	/*
	 * Obtener todos los lugares de la base de datos
	 * 
	 * @return Devuelve la lista de los lugares con sus atributos que
	 * 			hay en la base de datos
	 */
	@SuppressWarnings("unchecked")
	public static List<Lugar> getLugares(){
		EntityManager em = factoria.createEntityManager();
		
		// Hacemos la consulta.
		Query q = em.createQuery("SELECT u FROM Lugar u");
		List<Lugar> l = q.getResultList();
		
		// Cerramos el gestor.
		em.close();
		return l;
	}
	
	/*
	 * Muestra todos los lugares de la base de datos.
	 */
	@SuppressWarnings("unchecked")
	public static void mostrarBD() {
		// Abrimos el gestor de entidad
		EntityManager em = factoria.createEntityManager();

		// Hacemos la consulta
		Query q = em.createQuery("SELECT u FROM Lugar u");
		// Creamos una lista con todos los lugares a la que le asignamos
		//  el resultado de la consulta en la base de datos.
		List<Lugar> lugares = q.getResultList();
		
		em.close();
		//Imprimimos los lugares haciendo uso de su funci�n toString
		for (Lugar l: lugares) {
			System.out.println(l);
		}
		System.out.println("Tama�o: " + lugares.size());
	}

	/**
	 * Actualiza un lugar en la base de datos.
	 * @param idLugar : identificador de lugar que va a ser modificado 
	 * @param lugar : Tipo de dato Lugar con la informaci�n del nuevo lugar a grabar.
	 * */
	public static void actualizar(int idLugar, Lugar lugar) {
		Lugar lugarNuevo = new Lugar();
		EntityManager em = factoria.createEntityManager();
		// Buscamos el lugar en la base de datos
		lugarNuevo = em.find(Lugar.class, idLugar);
		// Comenzamos una transacci�n.
		em.getTransaction().begin();
		// Realizamos los cambios.
		lugarNuevo.setId(lugar.getId());
		lugarNuevo.setNombre(lugar.getNombre());
		lugarNuevo.setLatitud(lugar.getLatitud());
		lugarNuevo.setLongitud(lugar.getLongitud());
		lugarNuevo.setImagen(lugar.getImagen());
		lugarNuevo.setURL(lugar.getURL());
		// Hacemos permanentes los cambios.
		em.getTransaction().commit();
		
		// Cerramos el gestor.
		em.close();
		
		System.out.println("Lugar modificado.");
	}
	

	/**
	 * Elimina un lugar de la base de datos.
	 * @param lugar : lugar que se va a eliminar.
	 * 	(Es necesario que el 'id' del lugar est� en la base de datos)
	 * */
	public static void eliminar(Lugar lugar) {
		// Para esto, nos crearemos un gestor de entidades "fresco"
		EntityManager em = factoria.createEntityManager();
		// Buscamos el usuario en la base de datos.
		lugar = em.find(Lugar.class, lugar.getId());
		// Comenzamos la transacci�n.
		em.getTransaction().begin();
		// Borramos el usuario.
		em.remove(lugar);
		// La hacemos permanente.
		em.getTransaction().commit();
		// Cerramos el gestor.
		em.close();
		System.out.println("lugar eliminado.");
	}
	
	
	/*=================== Funciones auxiliares ==========================================*/
	/*
	 * Busca si existe un lugar en la base de datos
	 * @param lugar: lugar que se va a buscar.
	 */
	@SuppressWarnings("unchecked")
	private static boolean existeLugar(Lugar lugar) {
		EntityManager em = factoria.createEntityManager();
		// Comenzar una nueva transaccion local de tal manera que podamos hacer
		// persitente una nueva entidad
		// Ahora me creare la consulta necesaria eliminar la persona de nombre y
		// apellidos que indicare despues
		Query q = em.createQuery("SELECT u FROM Lugar u WHERE u.Nombre = :Nombre"
				+ " AND u.latitud = :latitud"
				+ " AND u.longitud = :longitud"
				+ " AND u.url = :url");
		// Ahora asigno los parametros
		q.setParameter("Nombre", lugar.getNombre());
		q.setParameter("latitud", lugar.getLatitud());
		q.setParameter("longitud", lugar.getLongitud());
		q.setParameter("url", lugar.getURL());
		// Ahora utilizo el metodo: "getSingleResult()" para obtener una lista de resultados
		// con esos par�metros
		List<Lugar> lu = q.getResultList();
		em.close();     
		//Si la lista tiene alg�n dato (size>0), entonces el lugar ya estaba en la BD
		if(lu.size() > 0){
			return true;
		}
		else{
			return false;
		}
	}
	
}
