package paqueteaguas;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


public enum LugarDao {
	instance;

	private Map<String, Lugar> contentProvider = new HashMap<String, Lugar>();

	private LugarDao() {

		List<Lugar> l = LugarBD.getLugares();
		
		
		for(int i = 0; i < l.size(); i++) {
			contentProvider.put(Integer.toString(i) , l.get(i));
		}

	}

	public Map<String, Lugar> getModel() {
		return contentProvider;
	}
}
