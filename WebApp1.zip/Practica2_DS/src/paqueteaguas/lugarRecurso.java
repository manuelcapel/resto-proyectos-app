package paqueteaguas;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;





@Path("/lugares")
public class lugarRecurso {

	
	
	/**
	 * 
	 * @return Devuelve la lista de los lugares que hay en formato XML.
	 */
	@GET
	@Path("/xml")
	@Produces({ MediaType.TEXT_XML })
	public static List<Lugar> getLugarXML() {
		List<Lugar> listaLugares = new ArrayList<Lugar>();
	
		listaLugares.addAll(LugarDao.instance.getModel().values());
		
		return listaLugares;
		
	}
	

	/**
	 *  Devuelve el numero de "lugares" que hay.
	 * 		Utilizar http://localhost:8080/mio.com.jersey.todo/rest/todos/count
	 * 		para obtener el numero total de registros
	 */
	@GET
	@Path("/numLugares")
	@Produces(MediaType.TEXT_PLAIN)
	public static String getCount() {
		return Integer.toString(LugarBD.getLugares().size());
	}	
	
	/**
	 * Este m�todo que encarga de crear un nuevo lugar.
	 * @param nombre: nombre del lugar
	 * @param latitud :  coordenadas de latitud del lugar para el google maps
	 * @param longitud :  coordenadas de longitud del lugar para el google maps
	 * @param url : direcci�n de la web que aloja el lugar
	 * @param imagenes : una imagen del lugar
	 * @param servletResponse : Servlet que nos va a proporcionar la respesta.
	 * @throws IOException : Lanza una excepci�n si existe alg�n problema de entrada/salida de datos.
	 */
	@POST
	@Path("/insertarLugar")
	@Produces(MediaType.TEXT_PLAIN) //TEXT_HTML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public static void newLugar(
			@FormParam("Nombre")    	String	Nombre,  
			@FormParam("latitud")		String 	latitud,
			@FormParam("longitud")		String 	longitud,
			@FormParam("url")  			String 	url,  
			@FormParam("imagenes") 		String 	imagenes,
			@FormParam("imagenes2") 	String 	imagenes2,
			
			@Context HttpServletResponse servletResponse) throws IOException {
		System.out.println(imagenes2);
		//Cambiamos las posibles comas (,) de la latitud y longitud en puntos (.)
		latitud = latitud.replaceAll(",", ".");
		longitud = longitud.replaceAll(",", ".");
		
		//Concretamos el lugar de donde se ha recibido la imagen
		//imagenes2 = "./imagenes/"+imagenes2;
		
		// Creamos el objeto lugar
		Lugar lugar = new Lugar(Nombre, latitud, longitud, url, imagenes);
		
		// Insertamos el lugar en la base de datos.
		LugarBD.insertar(lugar);
		servletResponse.sendRedirect("../../admin.jsp");
	}

	
	@POST
	@Path("/eliminarLugar")
	@Produces(MediaType.TEXT_HTML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public static void eliminarLugar(
		@FormParam("param") String 	id,
		@Context HttpServletResponse servletResponse) throws IOException {
	
		// Creamos el objeto lugar.
		LugarBD.eliminar(LugarBD.getLugar(Integer.parseInt(id)));
		System.out.println("Id del lugar eliminado: " + id);
		servletResponse.sendRedirect("../../admin.jsp");
	}

	/**
	 * 
	 * @return Devuelve el inventario de lugares para mostrarlos en HTML
	 */
	@GET
	@Path("/getInventario")
	@Produces({MediaType.TEXT_HTML})
	public static String getInventarioHTML() {
		List<Lugar> ll;
		// Obtenemos la lista de los lugares.
		ll = LugarBD.getLugares();			
		
		String inventarioHTML = "";
		
	
		for(Lugar l : ll) {
			
			inventarioHTML = inventarioHTML + l.getId() + "," + l.getNombre() + "," + l.getLatitud() + "," + l.getLongitud() + "," 
							+ l.getURL() + "," + l.getImagen() + "\n";

		}
		//el string devuelto sigue la siguiente estructura: id,nombre,latitud,longitud,url,imagen\nid,nombre,latitud......etc
		// las "," separan campos de la misma tupla y "\n" separa las diferentes tuplas.
		return inventarioHTML;
	}
	

	/**
	 * 
	 * @return Crea el script para poner un mapa de la api de Google Maps. Con los datos
	 * 			Latitud y Longitud se crean los marcadores del mapa
	 */
	@GET
	@Path("/getMarcadores")
	@Produces({MediaType.TEXT_HTML})
	public static String getMarcadoresHTML() {
		List<Lugar> ll;
		// Obtenemos la lista de los lugares.
		ll = LugarBD.getLugares();			
		
		String inventarioHTML = "";

		inventarioHTML+="<script src=\"http://maps.googleapis.com/maps/api/js\"></script>";
		inventarioHTML+="<script> var myCenter=new google.maps.LatLng(37.172533,-3.968030);";
			
			inventarioHTML+="function initialize(){";
				inventarioHTML+="var mapProp = { center:myCenter, zoom:8, mapTypeId:google.maps.MapTypeId.ROADMAP};";
				inventarioHTML+="var map=new google.maps.Map(document.getElementById(\"mapa\"),mapProp);";
				for(Lugar l : ll) {
					inventarioHTML+="var marker=new google.maps.Marker({position:new google.maps.LatLng("
							+ l.getLatitud() + "," + l.getLongitud() + "),});";
					inventarioHTML+="marker.setMap(map);";
					inventarioHTML+="marker.setTitle(\""+l.getNombre()+"\");";
					inventarioHTML+="google.maps.event.addListener(marker, 'click', function() {"
							+ "document.getElementById(\"infolugar\").innerHTML =\""+getLugarHTML(l.getId())
							+ "\";});";
				}
			inventarioHTML+="}"; //Fin funci�n initialize()
		inventarioHTML+="google.maps.event.addDomListener(window, \'load\', initialize);";
		inventarioHTML+="</script>";
	
		return inventarioHTML;
	}

	

	/**
	 * 
	 * @return Devuelve un lugar para mostrarlo en una p�gina html
	 */
	@GET
	@Path("/getLugarID")
	@Produces({MediaType.TEXT_HTML})
	public static String getLugarHTML(int id) {
		String SL="";
		Lugar lugar = LugarBD.getLugar(id);
		SL = "<h1>" + lugar.getNombre() + "</h1>" + 
			"<p><img src=\\\"" + lugar.getImagen() + "\\\"/></p>" + 
			"<h3> P�gina web de enlace al sitio </h3>" + 
			"<p><a href=\\\"" + lugar.getURL() + "\\\">" + lugar.getNombre() + "</a></p>";
		
		return SL;
	}	
	
	
	@POST
	@Path("/buscarLugares")
	@Produces(MediaType.TEXT_HTML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public static List<String> buscarLugares() {

		List<Lugar> ll = LugarBD.getLugares();
		String inventarioHTML = "";
		
		// Ahora insertamos cada uno de los lugares que hay.
		for(Lugar l : ll) {
			// Inicio de linea.
			inventarioHTML = inventarioHTML + "<tr>";
			// Cada uno de los atributos.
			inventarioHTML = inventarioHTML
					+ "<td>" + l.getId() 		+ 	"</td>"
					+ "<td>" + l.getNombre() 	+   "</td>"
			        + "<td>" + l.getLatitud() 	+   "</td>"
			        + "<td>" + l.getLongitud() 	+   "</td>"
			        + "<td>" + l.getURL() 		+   "</td>"
			        + "<td>" + l.getImagen() 	+   "</td>"
					
			        + "<td><form action=\"rest/lugares/eliminarLugar\" method=\"POST\">"
		        			+ "<input type=\"hidden\" name=\"param\" value=\""+l.getId()+"\" />"
		        			+ "<input class=\"button\" type=\"submit\" value=\"Eliminar\" />"
		        		+ "</form></td>";
			// Final de linea.
			inventarioHTML += "</tr>";
		}
		
		List<String> s = new ArrayList<String>();
		s.add(inventarioHTML); //Guardamos en la posici�n 0 el string de la tabla completa
		s.add(Integer.toString(ll.size())); //guardamos en la posici�n 1 la cantidad de lugares guardados
		return s;
	}
	
	/**
	 * 
	 * @return Devuelve los lugares de la Base de datos formateados en JSON
	 */
	@POST
	@Path("/buscarLugaresJSON")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public static List<String> buscarLugaresJSON() {

		List<Lugar> ll = LugarBD.getLugares();
		String inventarioJSON = "{\"lugares\":[<br>";
		
		int cont=0;
		// Ahora insertamos cada uno de los lugares que hay.
		for(Lugar l : ll) {
			inventarioJSON+="    {\"lugarid\":\""+l.getId()+"\",";
			inventarioJSON+="\"nombre\":\""+l.getNombre()+"\",";
			inventarioJSON+="\"latitud\":\""+l.getLatitud()+"\",";
			inventarioJSON+="\"longitud\":\""+l.getLongitud()+"\",";
			inventarioJSON+="\"url\":\""+l.getURL()+"\",";
			inventarioJSON+="\"imagenes\":\""+l.getImagen()+"\"}";
			cont++;
			if(cont<ll.size())
				inventarioJSON+=",";
			inventarioJSON+="<br>";
		}
		inventarioJSON+="]}";
		List<String> s = new ArrayList<String>();
		s.add(inventarioJSON); //Guardamos en la posici�n 0 el string de la tabla completa
		s.add(Integer.toString(ll.size())); //guardamos en la posici�n 1 la cantidad de lugares guardados
		return s;
	}
	
	
	/**
	 * 
	 * @return Devuelve los lugares de la Base de datos formateados en XML
	 */
	@POST
	@Path("/buscarLugaresXML")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	public static List<String> buscarLugaresXML() {

		List<Lugar> ll = LugarBD.getLugares();
		String inventarioXML = "&lt;lugares&gt;<br>";
		//Cambiamos los <> por  &lt; y &gt; respectivamente para que los muestre y no los interprete
		// Ahora insertamos cada uno de los lugares que hay.
		for(Lugar l : ll) {
			inventarioXML+="    &lt;lugar&gt;<br>";
			inventarioXML+="        &lt;lugarid&gt;"+l.getId()+"&lt;/lugarid&gt;";
			inventarioXML+=" &lt;nombre&gt;"+l.getNombre()+"&lt;/nombre&gt;";
			inventarioXML+=" &lt;latitud&gt;"+l.getLatitud()+"&lt;/latitud&gt;";
			inventarioXML+=" &lt;longitud&gt;"+l.getLongitud()+"&lt;/longitud&gt;";
			inventarioXML+=" &lt;url&gt;"+l.getURL()+"&lt;/url&gt;";
			inventarioXML+=" &lt;imagenes&gt;"+l.getImagen()+"&lt;/imagenes&gt;<br>";
			inventarioXML+="    &lt;/lugar&gt;<br>";
		}
		inventarioXML+="&lt;/lugares&gt;<br>";
		
		List<String> s = new ArrayList<String>();
		s.add(inventarioXML); //Guardamos en la posici�n 0 el string de la tabla completa
		s.add(Integer.toString(ll.size())); //guardamos en la posici�n 1 la cantidad de lugares guardados
		return s;
	}
}

